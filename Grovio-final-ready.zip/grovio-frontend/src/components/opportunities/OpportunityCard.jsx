import { Bookmark, BookmarkCheck, MapPin } from 'lucide-react';
import Card from '../ui/Card.jsx';
import Pill from '../ui/Pill.jsx';
import { MatchBar } from '../ui/Misc.jsx';

export default function OpportunityCard({ opportunity, saved, onToggleSave }) {
  const { companyName, title, type, location, compensationOrPrize, daysLeft, matchPercent, applyUrl } = opportunity;

  return (
    <Card>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div>
          <div style={{ fontWeight: 600, fontSize: 14.5 }}>{title}</div>
          <div className="muted" style={{ fontSize: 12.5, marginTop: 2 }}>{companyName}</div>
        </div>
        {typeof matchPercent === 'number' && <Pill tone="success">{matchPercent}% match</Pill>}
      </div>

      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', margin: '12px 0' }}>
        <Pill>{type}</Pill>
        {location && (
          <Pill>
            <MapPin size={11} /> {location}
          </Pill>
        )}
        {typeof daysLeft === 'number' && <Pill tone={daysLeft <= 2 ? 'warning' : undefined}>{daysLeft} day{daysLeft === 1 ? '' : 's'} left</Pill>}
      </div>

      {compensationOrPrize && <div className="faint" style={{ fontSize: 12, marginBottom: 10 }}>{compensationOrPrize}</div>}

      {typeof matchPercent === 'number' && <MatchBar percent={matchPercent} />}

      <div style={{ display: 'flex', gap: 10, marginTop: 16 }}>
        <a
          href={applyUrl || '#'}
          target="_blank"
          rel="noreferrer"
          className="btn btn-primary btn-sm"
          style={{ flex: 1, justifyContent: 'center' }}
          onClick={(e) => { if (!applyUrl) e.preventDefault(); }}
        >
          Apply
        </a>
        <button
          type="button"
          className="btn btn-ghost btn-sm"
          onClick={onToggleSave}
          aria-label={saved ? 'Unsave' : 'Save'}
          title={saved ? 'Saved (not synced to backend yet)' : 'Save'}
        >
          {saved ? <BookmarkCheck size={15} /> : <Bookmark size={15} />}
        </button>
      </div>
    </Card>
  );
}
