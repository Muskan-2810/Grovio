import { MatchBar } from '../ui/Misc.jsx';

export default function CareerMetric({ label, value }) {
  return (
    <div style={{ marginBottom: 14 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13 }}>
        <span>{label}</span>
        <span className="faint">{value}%</span>
      </div>
      <MatchBar percent={value} />
    </div>
  );
}
