export default function SuggestedPrompt({ text, onClick }) {
  return (
    <button
      type="button"
      className="pill"
      style={{ cursor: 'pointer', padding: '9px 14px', fontSize: 12, fontWeight: 500, textAlign: 'left' }}
      onClick={() => onClick(text)}
    >
      {text}
    </button>
  );
}
