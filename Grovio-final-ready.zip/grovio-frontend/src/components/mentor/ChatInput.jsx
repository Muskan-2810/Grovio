import { useState } from 'react';
import { Send } from 'lucide-react';

export default function ChatInput({ onSend, disabled }) {
  const [value, setValue] = useState('');

  const submit = (e) => {
    e.preventDefault();
    const trimmed = value.trim();
    if (!trimmed || disabled) return;
    onSend(trimmed);
    setValue('');
  };

  return (
    <form onSubmit={submit} style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
      <div className="glass" style={{ flex: 1, borderRadius: 10, padding: '11px 14px' }}>
        <input
          value={value}
          onChange={(e) => setValue(e.target.value)}
          placeholder="Ask your mentor anything…"
          style={{ width: '100%', fontSize: 13.5 }}
          disabled={disabled}
        />
      </div>
      <button type="submit" className="btn btn-primary" disabled={disabled || !value.trim()} aria-label="Send">
        <Send size={16} />
      </button>
    </form>
  );
}
