import { AiGlyph } from '../ui/Misc.jsx';

export default function ChatMessage({ role, content }) {
  const isUser = role === 'user';

  return (
    <div style={{ display: 'flex', gap: 10, justifyContent: isUser ? 'flex-end' : 'flex-start', marginBottom: 16 }}>
      {!isUser && <AiGlyph>G</AiGlyph>}
      <div
        style={{
          maxWidth: '72%',
          padding: '11px 15px',
          borderRadius: 12,
          fontSize: 13.5,
          lineHeight: 1.55,
          background: isUser ? 'var(--accent)' : 'var(--surface)',
          color: isUser ? '#0B0B0B' : 'var(--text-1)',
          border: isUser ? 'none' : '1px solid var(--border)',
        }}
      >
        {content}
      </div>
    </div>
  );
}
