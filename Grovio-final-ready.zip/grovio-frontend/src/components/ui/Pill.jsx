export default function Pill({ tone, className = '', children, as: As = 'span', ...rest }) {
  // tone: 'purple' | 'blue' | 'success' | 'warning' | undefined
  const toneClass = tone ? tone : '';
  return (
    <As className={`pill ${toneClass} ${className}`.trim()} {...rest}>
      {children}
    </As>
  );
}
