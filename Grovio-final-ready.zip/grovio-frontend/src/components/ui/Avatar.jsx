export default function Avatar({ children, rounded = false, size, style, className = '', ...rest }) {
  const extraStyle = {
    borderRadius: rounded ? '10px' : undefined,
    width: size,
    height: size,
    fontSize: size ? Math.round(size * 0.35) : undefined,
    ...style,
  };
  return (
    <div className={`avatar ${className}`.trim()} style={extraStyle} {...rest}>
      {children}
    </div>
  );
}
