export default function Card({ className = '', fadeUp = false, style, children, ...rest }) {
  return (
    <div className={`card ${fadeUp ? 'fade-up' : ''} ${className}`.trim()} style={style} {...rest}>
      {children}
    </div>
  );
}
