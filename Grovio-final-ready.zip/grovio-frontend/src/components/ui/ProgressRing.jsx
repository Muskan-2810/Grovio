import { useId } from 'react';

/**
 * Circular "Career Pulse" progress ring.
 * score: 0-100
 * size: outer wrapper size in px (default 118, matches dashboard usage)
 */
export default function ProgressRing({ score = 0, size = 118, label = 'out of 100' }) {
  const gradId = useId();
  const radius = 50;
  const circumference = 2 * Math.PI * radius; // ~314
  const clamped = Math.max(0, Math.min(100, score));
  const dashOffset = circumference - (clamped / 100) * circumference;

  return (
    <div className="ring-wrap" style={{ width: size, height: size }}>
      <svg width={size} height={size} viewBox="0 0 118 118">
        <defs>
          <linearGradient id={gradId} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#CDB18A" />
            <stop offset="100%" stopColor="#D7C3A3" />
          </linearGradient>
        </defs>
        <circle className="ring-bg" cx="59" cy="59" r={radius} />
        <circle
          className="ring-fg"
          cx="59"
          cy="59"
          r={radius}
          strokeDasharray={circumference}
          strokeDashoffset={dashOffset}
          style={{ stroke: `url(#${gradId})` }}
        />
      </svg>
      <div className="ring-center">
        <div className="num" style={size > 118 ? { fontSize: 32 } : undefined}>{clamped}</div>
        <div className="lbl">{label}</div>
      </div>
    </div>
  );
}
