export default function Button({
  variant = 'primary', // 'primary' | 'ghost'
  size, // 'sm' | undefined
  className = '',
  children,
  as: As = 'button',
  ...rest
}) {
  const variantClass = variant === 'ghost' ? 'btn-ghost' : 'btn-primary';
  const sizeClass = size === 'sm' ? 'btn-sm' : '';
  return (
    <As className={`btn ${variantClass} ${sizeClass} ${className}`.trim()} {...rest}>
      {children}
    </As>
  );
}
