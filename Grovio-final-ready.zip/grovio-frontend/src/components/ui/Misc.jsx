export function Eyebrow({ children, style, className = '' }) {
  return (
    <div className={`eyebrow ${className}`.trim()} style={style}>
      {children}
    </div>
  );
}

export function AiInsight({ children, style }) {
  return (
    <div className="ai-insight" style={style}>
      {children}
    </div>
  );
}

export function MatchBar({ percent = 0 }) {
  return (
    <div className="match-bar-track">
      <div className="match-bar-fill" style={{ width: `${percent}%` }} />
    </div>
  );
}

export function MissionBar({ percent = 0 }) {
  return (
    <div className="mission-track">
      <div className="mission-fill" style={{ width: `${percent}%` }} />
    </div>
  );
}

export function AiGlyph({ size = 22, children = 'G' }) {
  return (
    <div className="ai-glyph" style={{ width: size, height: size, fontSize: Math.round(size * 0.5) }}>
      {children}
    </div>
  );
}

export function TypingDots() {
  return (
    <span className="typing-dots">
      <span></span>
      <span></span>
      <span></span>
    </span>
  );
}

export function MarkCircle({ children, style }) {
  return (
    <div className="mark-circle" style={style}>
      {children}
    </div>
  );
}
