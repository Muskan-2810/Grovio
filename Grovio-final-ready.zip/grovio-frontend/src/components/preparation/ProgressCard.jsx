import Card from '../ui/Card.jsx';
import { Eyebrow, MatchBar } from '../ui/Misc.jsx';

export default function ProgressCard({ overallPercent, completedCount, totalCount, currentTopic, nextTopic }) {
  return (
    <Card>
      <Eyebrow style={{ marginBottom: 14 }}>◆ Your preparation progress</Eyebrow>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 8 }}>
        <span className="font-display" style={{ fontSize: 28 }}>{overallPercent}%</span>
        <span className="faint" style={{ fontSize: 12 }}>{completedCount} of {totalCount} topics</span>
      </div>
      <MatchBar percent={overallPercent} />
      <div className="grid" style={{ gridTemplateColumns: '1fr 1fr', marginTop: 18, gap: 12 }}>
        <div>
          <div className="faint" style={{ fontSize: 11 }}>Current topic</div>
          <div style={{ fontSize: 13.5, fontWeight: 500 }}>{currentTopic || '—'}</div>
        </div>
        <div>
          <div className="faint" style={{ fontSize: 11 }}>Recommended next</div>
          <div style={{ fontSize: 13.5, fontWeight: 500 }}>{nextTopic || '—'}</div>
        </div>
      </div>
    </Card>
  );
}
