import Card from '../ui/Card.jsx';
import Pill from '../ui/Pill.jsx';
import { MatchBar } from '../ui/Misc.jsx';

const DIFFICULTY_TONE = { Easy: 'success', Medium: 'warning', Hard: undefined };

export default function TopicCard({ title, difficulty, progressPercent = 0, onContinue }) {
  return (
    <Card>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 10 }}>
        <div style={{ fontWeight: 600, fontSize: 14 }}>{title}</div>
        {difficulty && <Pill tone={DIFFICULTY_TONE[difficulty]}>{difficulty}</Pill>}
      </div>
      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11.5 }} className="faint">
        <span>Progress</span>
        <span>{progressPercent}%</span>
      </div>
      <MatchBar percent={progressPercent} />
      <button className="btn btn-ghost btn-sm" style={{ marginTop: 14, width: '100%', justifyContent: 'center' }} onClick={onContinue}>
        Continue
      </button>
    </Card>
  );
}
