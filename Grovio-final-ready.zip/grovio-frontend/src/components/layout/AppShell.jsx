import Sidebar from './Sidebar.jsx';
import Topbar from './Topbar.jsx';

export default function AppShell({ title, subtitle, streak, bestStreak, children }) {
  return (
    <div className="app-shell">
      <Sidebar streak={streak} bestStreak={bestStreak} />
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
        <Topbar title={title} subtitle={subtitle} />
        <div className="main-area screen-enter">{children}</div>
      </div>
    </div>
  );
}
