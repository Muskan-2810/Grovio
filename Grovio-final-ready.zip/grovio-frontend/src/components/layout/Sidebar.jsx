import { NavLink } from 'react-router-dom';
import { LayoutDashboard, Sparkles, BookOpen, Briefcase, FileText, Gauge, User } from 'lucide-react';

const NAV = [
  { to: '/dashboard', label: 'Dashboard', Icon: LayoutDashboard },
  { to: '/mentor', label: 'AI Mentor', Icon: Sparkles },
  { to: '/prep', label: 'Preparation Hub', Icon: BookOpen },
  { to: '/opportunities', label: 'Opportunity Hub', Icon: Briefcase },
];

const NAV_GROWTH = [
  { to: '/resume', label: 'Resume Intelligence', Icon: FileText },
  { to: '/score', label: 'Career Score', Icon: Gauge },
];

function NavItem({ item }) {
  const { Icon } = item;
  return (
    <NavLink to={item.to} className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}>
      <Icon size={16} />
      {item.label}
    </NavLink>
  );
}

export default function Sidebar({ streak, bestStreak }) {
  const hasStreakData = typeof streak === 'number';

  return (
    <aside className="sidebar">
      <div className="side-logo">
        <div className="mark" />
        <span>Grovio</span>
      </div>

      {NAV.map((n) => <NavItem key={n.to} item={n} />)}

      <div className="nav-group-label">Growth</div>
      {NAV_GROWTH.map((n) => <NavItem key={n.to} item={n} />)}

      <div className="nav-group-label">Account</div>
      <NavItem item={{ to: '/profile', label: 'Profile', Icon: User }} />

      <div className="sidebar-footer">
        <div className="streak-chip">
          <span className="mark-circle" style={{ width: 26, height: 26, fontSize: 11 }}>
            {hasStreakData ? streak : '–'}
          </span>
          <div>
            <div style={{ fontWeight: 600 }}>Day streak</div>
            <div className="faint" style={{ fontSize: 11 }}>
              {hasStreakData ? `Best: ${bestStreak} days` : 'Loading…'}
            </div>
          </div>
        </div>
      </div>
    </aside>
  );
}
