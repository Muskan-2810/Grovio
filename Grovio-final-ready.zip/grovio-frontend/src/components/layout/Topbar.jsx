import { useNavigate } from 'react-router-dom';
import { Search, Bell, Settings, LogOut } from 'lucide-react';
import { useAuth } from '../../context/AuthContext.jsx';

function getInitials(fullName) {
  if (!fullName) return '?';
  const parts = fullName.trim().split(/\s+/);
  const initials = parts.length > 1 ? parts[0][0] + parts[parts.length - 1][0] : parts[0].slice(0, 2);
  return initials.toUpperCase();
}

export default function Topbar({ title, subtitle }) {
  const navigate = useNavigate();
  const { user, logout } = useAuth();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <div className="topbar">
      <div>
        <div style={{ fontFamily: "'Fraunces',serif", fontWeight: 500, fontSize: 17 }}>{title}</div>
        {subtitle ? <div className="muted" style={{ fontSize: 12.5 }}>{subtitle}</div> : null}
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <div className="search-bar">
          <Search size={14} />
          <span>Search Grovio...</span>
          <span className="kbd" style={{ marginLeft: 'auto' }}>⌘K</span>
        </div>
        <button className="icon-btn" onClick={() => navigate('/dashboard')} aria-label="Notifications" title="Notifications (not built yet)">
          <Bell size={16} />
        </button>
        <button className="icon-btn" onClick={() => navigate('/profile')} aria-label="Settings" title="Settings live in Profile for now">
          <Settings size={16} />
        </button>
        <div
          className="avatar"
          style={{ cursor: 'pointer' }}
          onClick={() => navigate('/profile')}
          title={user?.fullName}
        >
          {getInitials(user?.fullName)}
        </div>
        <button className="icon-btn" onClick={handleLogout} aria-label="Log out" title="Log out">
          <LogOut size={16} />
        </button>
      </div>
    </div>
  );
}
