export default function ResumeInsight({ label, items, tone = 'neutral' }) {
  const color = tone === 'positive' ? 'var(--success)' : tone === 'negative' ? 'var(--danger)' : 'var(--text-2)';

  return (
    <div style={{ marginBottom: 16 }}>
      <div style={{ fontSize: 11.5, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '.04em', color, marginBottom: 8 }}>
        {label}
      </div>
      <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: 6 }}>
        {items.map((item, i) => (
          <li key={i} style={{ fontSize: 13, color: 'var(--text-2)' }}>— {item}</li>
        ))}
      </ul>
    </div>
  );
}
