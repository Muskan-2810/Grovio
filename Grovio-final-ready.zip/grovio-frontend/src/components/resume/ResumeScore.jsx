import Card from '../ui/Card.jsx';
import ProgressRing from '../ui/ProgressRing.jsx';
import { Eyebrow } from '../ui/Misc.jsx';

export default function ResumeScore({ overallScore, atsScore }) {
  return (
    <Card>
      <Eyebrow style={{ marginBottom: 14 }}>◆ Resume score</Eyebrow>
      <ProgressRing score={overallScore ?? 0} label="overall" />
      {typeof atsScore === 'number' && (
        <p className="muted" style={{ textAlign: 'center', fontSize: 12, marginTop: 10 }}>
          ATS / readability: {atsScore}/100
        </p>
      )}
    </Card>
  );
}
