import { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { registerUser, loginUser, fetchCurrentUser, updateProfile as updateProfileRequest } from '../lib/authService.js';

/**
 * SECURITY TRADEOFF — where the JWT is stored
 * ---------------------------------------------
 * Two realistic options existed here:
 *
 * 1. localStorage (what this file does)
 *    + Simple: plain JS reads it, api.js attaches it to every request itself.
 *    + Works with the backend exactly as it exists today — no server changes.
 *    - Readable by any JS that runs on the page, so an XSS bug becomes a
 *      token-theft bug. There's no server-side way to revoke a stolen token
 *      before it expires.
 *
 * 2. HttpOnly cookie, set by the backend on login/register
 *    + Not readable by JavaScript at all, so a plain XSS bug can't read the
 *      token directly — meaningfully better default security.
 *    - Requires real backend changes this project doesn't have yet: the
 *      Spring Security filter chain would need to read the token from a
 *      cookie instead of an Authorization header, login/register would need
 *      to set a Set-Cookie response, and CSRF protection would need to come
 *      back on (it's currently disabled because there's no cookie-based
 *      session to protect).
 *
 * This project uses localStorage because it matches "the simplest approach
 * compatible with the existing backend" — the backend only ever reads
 * `Authorization: Bearer <token>` (see JwtAuthenticationFilter), and changing
 * that is a real architecture change, not a Phase 1 fix. Moving to HttpOnly
 * cookies is a reasonable Phase 3 security improvement if this ships as a
 * real product with real user accounts.
 */
const AuthContext = createContext(null);

const TOKEN_KEY = 'grovio_token';
const USER_KEY = 'grovio_user';

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    const cached = localStorage.getItem(USER_KEY);
    return cached ? JSON.parse(cached) : null;
  });
  const [token, setToken] = useState(() => localStorage.getItem(TOKEN_KEY));
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const persistSession = (accessToken, userData) => {
    localStorage.setItem(TOKEN_KEY, accessToken);
    localStorage.setItem(USER_KEY, JSON.stringify(userData));
    setToken(accessToken);
    setUser(userData);
  };

  const clearSession = () => {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(USER_KEY);
    setToken(null);
    setUser(null);
  };

  // On first load, if we have a token, verify it's still valid against /auth/me
  // rather than trusting the cached user forever.
  useEffect(() => {
    const bootstrap = async () => {
      const existingToken = localStorage.getItem(TOKEN_KEY);
      if (!existingToken) {
        setLoading(false);
        return;
      }
      try {
        const freshUser = await fetchCurrentUser();
        setUser(freshUser);
        localStorage.setItem(USER_KEY, JSON.stringify(freshUser));
      } catch {
        clearSession();
      } finally {
        setLoading(false);
      }
    };
    bootstrap();
  }, []);

  const login = useCallback(async (credentials) => {
    setError(null);
    try {
      const data = await loginUser(credentials); // { accessToken, tokenType, expiresIn, user }
      persistSession(data.accessToken, data.user);
      return data.user;
    } catch (err) {
      setError(err.message);
      throw err;
    }
  }, []);

  const register = useCallback(async (payload) => {
    setError(null);
    try {
      const data = await registerUser(payload);
      persistSession(data.accessToken, data.user);
      return data.user;
    } catch (err) {
      setError(err.message);
      throw err;
    }
  }, []);

  const logout = useCallback(() => {
    clearSession();
  }, []);

  const updateProfile = useCallback(async (profileData) => {
    const updatedUser = await updateProfileRequest(profileData);
    setUser(updatedUser);
    localStorage.setItem(USER_KEY, JSON.stringify(updatedUser));
    return updatedUser;
  }, []);

  const value = {
    user,
    token,
    isAuthenticated: Boolean(token && user),
    loading,
    error,
    login,
    register,
    logout,
    updateProfile,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return ctx;
}
