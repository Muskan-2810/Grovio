import { useNavigate } from 'react-router-dom';
import Pill from '../components/ui/Pill.jsx';
import Card from '../components/ui/Card.jsx';
import { Eyebrow } from '../components/ui/Misc.jsx';

const REPLACES = [
  { num: '01', title: 'Opportunities', desc: 'Internships, jobs & hackathons, matched daily.' },
  { num: '02', title: 'DSA · Java · SQL', desc: 'Structured roadmaps, not random videos.' },
  { num: '03', title: 'Company sheets', desc: 'Interview prep tailored to the employer.' },
  { num: '04', title: 'AI mentor', desc: 'Someone to ask, any time of day.' },
];

export default function Landing() {
  const navigate = useNavigate();

  return (
    <section className="screen-enter">
      <nav
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          padding: '22px 40px',
          position: 'relative',
          zIndex: 2,
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
          <div style={{ width: 28, height: 28, borderRadius: 8, background: 'var(--grad)' }} />
          <span className="font-display" style={{ fontWeight: 500, fontSize: 19 }}>Grovio</span>
        </div>
        <div className="mono" style={{ display: 'flex', gap: 32, fontSize: 13.5, color: 'var(--text-2)' }}>
          <a href="#product">Product</a>
          <a href="#how-it-works">How it works</a>
          <a href="#for-colleges">For colleges</a>
        </div>
        <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
          <a className="btn-ghost btn" style={{ padding: '9px 16px' }} onClick={() => navigate('/login')}>
            Log in
          </a>
          <a className="btn btn-primary" onClick={() => navigate('/onboarding')}>
            Get started
          </a>
        </div>
      </nav>

      <div className="container" style={{ position: 'relative', zIndex: 2, paddingTop: 64, textAlign: 'center' }}>
        <div className="fade-up" style={{ display: 'inline-flex', marginBottom: 22 }}>
          <Pill tone="purple">● Now guiding 12,000+ students daily</Pill>
        </div>
        <h1
          className="fade-up font-display"
          style={{ fontSize: 58, lineHeight: 1.12, fontWeight: 500, maxWidth: 820, margin: '0 auto 22px' }}
        >
          Stop scattering your career across{' '}
          <span
            style={{
              background: 'var(--grad)',
              WebkitBackgroundClip: 'text',
              backgroundClip: 'text',
              color: 'transparent',
            }}
          >
            twelve tabs.
          </span>
        </h1>
        <p
          className="fade-up muted"
          style={{ fontSize: 18, maxWidth: 560, margin: '0 auto 34px', lineHeight: 1.6, animationDelay: '.1s' }}
        >
          Grovio is the AI companion that sits beside you through placements — internships, DSA, interviews,
          resumes, deadlines — guided daily, not dumped all at once.
        </p>
        <div className="fade-up" style={{ display: 'flex', gap: 14, justifyContent: 'center', animationDelay: '.2s' }}>
          <a className="btn btn-primary" style={{ padding: '14px 26px', fontSize: 15 }} onClick={() => navigate('/onboarding')}>
            Start your journey — free
          </a>
          <a className="btn btn-ghost" style={{ padding: '14px 26px', fontSize: 15 }} onClick={() => navigate('/dashboard')}>
            See the companion in action
          </a>
        </div>

        {/* product preview */}
        <div className="fade-up" style={{ marginTop: 64, animationDelay: '.3s' }}>
          <Card style={{ textAlign: 'left', padding: 26, maxWidth: 900, margin: '0 auto', boxShadow: 'var(--shadow)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 18 }}>
              <Eyebrow>◆ Today, 8:42 AM</Eyebrow>
              <Pill tone="success">6-day streak</Pill>
            </div>
            <p style={{ fontSize: 16, fontWeight: 500, marginBottom: 20 }}>
              Morning, Aditi. You're 2 problems from finishing Recursion — and Razorpay's SDE internship closes tomorrow.
            </p>
            <div className="grid grid-3" style={{ gridTemplateColumns: '1fr 1fr 1fr' }}>
              <div className="glass" style={{ borderRadius: 12, padding: 14 }}>
                <div className="faint" style={{ fontSize: 11, marginBottom: 6 }}>Today's plan</div>
                <div style={{ fontSize: 13 }}>Recursion — Pattern 4 · 18 min</div>
              </div>
              <div className="glass" style={{ borderRadius: 12, padding: 14 }}>
                <div className="faint" style={{ fontSize: 11, marginBottom: 6 }}>MATCHED FOR YOU</div>
                <div style={{ fontSize: 13 }}>Razorpay · SDE Intern · ₹50k/mo</div>
              </div>
              <div className="glass" style={{ borderRadius: 12, padding: 14 }}>
                <div className="faint" style={{ fontSize: 11, marginBottom: 6 }}>READINESS</div>
                <div style={{ fontSize: 13 }}>72/100 · ↑ 4 this week</div>
              </div>
            </div>
          </Card>
        </div>
      </div>

      <div className="container" id="product" style={{ marginTop: 120, position: 'relative', zIndex: 2 }}>
        <div style={{ textAlign: 'center', marginBottom: 46 }}>
          <Eyebrow style={{ justifyContent: 'center' }}>◆ Everything, one place</Eyebrow>
          <h2 className="font-display" style={{ fontSize: 32, marginTop: 10 }}>
            Replaces the WhatsApp groups. Replaces the Telegram channels.
          </h2>
        </div>
        <div className="grid grid-4" style={{ gridTemplateColumns: 'repeat(4,1fr)' }}>
          {REPLACES.map((r) => (
            <Card key={r.num}>
              <div className="mark-num">{r.num}</div>
              <div style={{ fontWeight: 600, marginBottom: 6 }}>{r.title}</div>
              <div className="muted" style={{ fontSize: 13 }}>{r.desc}</div>
            </Card>
          ))}
        </div>
      </div>

      <div className="container" id="how-it-works" style={{ marginTop: 90, position: 'relative', zIndex: 2 }}>
        <Card style={{ padding: 44, textAlign: 'center', background: 'var(--grad-soft)', borderColor: 'rgba(215,195,163,0.28)' }}>
          <Eyebrow style={{ justifyContent: 'center', marginBottom: 12 }}>◆ This is not a resume scanner</Eyebrow>
          <h2 className="font-display" style={{ fontSize: 28, maxWidth: 640, margin: '0 auto 14px' }}>
            Other tools score you once and disappear. Grovio shows up every day.
          </h2>
          <p className="muted" style={{ maxWidth: 520, margin: '0 auto' }}>
            A resume grade doesn't get you placed. Daily guidance — what to study, what to apply to, when to prep —
            does.
          </p>
        </Card>
      </div>

      <footer
        className="container"
        id="for-colleges"
        style={{
          marginTop: 90,
          padding: '36px 32px',
          borderTop: '1px solid var(--border)',
          display: 'flex',
          justifyContent: 'space-between',
          color: 'var(--text-3)',
          fontSize: 12.5,
        }}
      >
        <span>© 2026 Grovio</span>
        <span>Built for students who are tired of figuring it out alone.</span>
      </footer>
    </section>
  );
}
