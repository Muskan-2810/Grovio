import { useState } from 'react';
import AppShell from '../components/layout/AppShell.jsx';
import Card from '../components/ui/Card.jsx';
import Avatar from '../components/ui/Avatar.jsx';
import Pill from '../components/ui/Pill.jsx';
import { Eyebrow } from '../components/ui/Misc.jsx';
import { useAuth } from '../context/AuthContext.jsx';

const STRENGTH_OPTIONS = ['DSA', 'Java', 'SQL', 'Web Development', 'CS Fundamentals', 'Aptitude'];

export default function Profile() {
  const { user, updateProfile } = useAuth();
  const [editing, setEditing] = useState(false);
  const [careerGoal, setCareerGoal] = useState(user?.careerGoal || '');
  const [strengths, setStrengths] = useState(user?.strengths || []);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);

  const toggleStrength = (s) => {
    setStrengths((prev) => (prev.includes(s) ? prev.filter((x) => x !== s) : [...prev, s]));
  };

  const handleSave = async () => {
    setSaving(true);
    setError(null);
    try {
      await updateProfile({ careerGoal, strengths });
      setEditing(false);
    } catch (err) {
      setError(err.message || 'Could not save your profile.');
    } finally {
      setSaving(false);
    }
  };

  if (!user) return null; // ProtectedRoute guarantees this shouldn't render logged-out

  return (
    <AppShell title="Profile" subtitle="Your account and career details">
      <div className="grid" style={{ gridTemplateColumns: '260px 1fr', gap: 20, alignItems: 'start' }}>
        <Card style={{ textAlign: 'center' }}>
          <Avatar rounded={false} size={72} style={{ margin: '0 auto 14px', fontSize: 24 }}>
            {user.fullName?.[0]?.toUpperCase() || '?'}
          </Avatar>
          <div style={{ fontWeight: 600, fontSize: 15 }}>{user.fullName}</div>
          <div className="faint" style={{ fontSize: 12, marginTop: 2 }}>{user.email}</div>
        </Card>

        <Card>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
            <Eyebrow>◆ Account details</Eyebrow>
            {!editing && (
              <button className="btn btn-ghost btn-sm" onClick={() => setEditing(true)}>Edit</button>
            )}
          </div>

          <div className="grid" style={{ gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 20 }}>
            <Field label="College" value={user.college} />
            <Field label="Branch" value={user.branch} />
            <Field label="Graduation year" value={user.graduationYear} />
            <Field label="Email" value={user.email} />
          </div>

          <div className="hr" style={{ margin: '18px 0' }} />

          <div className="faint" style={{ fontSize: 11.5, textTransform: 'uppercase', marginBottom: 8 }}>Career goal</div>
          {editing ? (
            <div className="glass" style={{ borderRadius: 10, padding: '11px 14px', marginBottom: 18 }}>
              <input
                value={careerGoal}
                onChange={(e) => setCareerGoal(e.target.value)}
                placeholder="e.g. Full-time placement"
                style={{ width: '100%', fontSize: 13.5 }}
              />
            </div>
          ) : (
            <p style={{ fontSize: 13.5, marginBottom: 18 }}>{user.careerGoal || '—'}</p>
          )}

          <div className="faint" style={{ fontSize: 11.5, textTransform: 'uppercase', marginBottom: 8 }}>Strengths</div>
          {editing ? (
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginBottom: 20 }}>
              {STRENGTH_OPTIONS.map((s) => (
                <span
                  key={s}
                  className={`pill ${strengths.includes(s) ? 'purple' : ''}`}
                  style={{ cursor: 'pointer' }}
                  onClick={() => toggleStrength(s)}
                >
                  {s}
                </span>
              ))}
            </div>
          ) : (
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginBottom: 20 }}>
              {user.strengths?.length ? user.strengths.map((s) => <Pill key={s}>{s}</Pill>) : <span className="muted" style={{ fontSize: 13 }}>—</span>}
            </div>
          )}

          {error && <p style={{ color: 'var(--danger)', fontSize: 12.5, marginBottom: 14 }}>{error}</p>}

          {editing && (
            <div style={{ display: 'flex', gap: 10 }}>
              <button className="btn btn-primary" onClick={handleSave} disabled={saving}>
                {saving ? 'Saving…' : 'Save changes'}
              </button>
              <button className="btn btn-ghost" onClick={() => setEditing(false)} disabled={saving}>Cancel</button>
            </div>
          )}
        </Card>
      </div>
    </AppShell>
  );
}

function Field({ label, value }) {
  return (
    <div>
      <div className="faint" style={{ fontSize: 11 }}>{label}</div>
      <div style={{ fontSize: 13.5, marginTop: 2 }}>{value || '—'}</div>
    </div>
  );
}
