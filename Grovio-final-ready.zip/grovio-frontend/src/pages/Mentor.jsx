import { useState } from 'react';
import AppShell from '../components/layout/AppShell.jsx';
import Card from '../components/ui/Card.jsx';
import { Eyebrow } from '../components/ui/Misc.jsx';
import ChatMessage from '../components/mentor/ChatMessage.jsx';
import ChatInput from '../components/mentor/ChatInput.jsx';
import SuggestedPrompt from '../components/mentor/SuggestedPrompt.jsx';
import { useAuth } from '../context/AuthContext.jsx';
import { sendMentorMessage } from '../lib/mentorService.js';

const PROMPTS = [
  'Which career path should I focus on?',
  'How should I prepare for software engineering interviews?',
  'Help me improve my DSA preparation.',
  'What skills should I learn for my target role?',
  'Review my current career progress.',
];

export default function Mentor() {
  const { user } = useAuth();
  const [messages, setMessages] = useState([]);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState(null);

  const firstName = user?.fullName?.split(' ')[0] || 'there';

  const handleSend = async (text) => {
    setError(null);
    setMessages((prev) => [...prev, { role: 'user', content: text }]);
    setSending(true);
    try {
      const reply = await sendMentorMessage(text);
      setMessages((prev) => [...prev, { role: 'mentor', content: reply.content }]);
    } catch (err) {
      // Backend doesn't have this endpoint yet (see mentorService.js) —
      // show that honestly instead of inventing a reply.
      setError(err.message || 'The mentor is not available yet.');
    } finally {
      setSending(false);
    }
  };

  return (
    <AppShell title="AI Mentor" subtitle={`Hey ${firstName}, what's on your mind?`}>
      <div className="grid" style={{ gridTemplateColumns: '1.6fr 1fr', gap: 20, alignItems: 'start' }}>
        {/* Chat area */}
        <Card style={{ display: 'flex', flexDirection: 'column', minHeight: 480 }}>
          <Eyebrow style={{ marginBottom: 16 }}>◆ Conversation</Eyebrow>

          <div style={{ flex: 1, overflowY: 'auto', marginBottom: 16 }}>
            {messages.length === 0 ? (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                <p className="muted" style={{ fontSize: 13.5, marginBottom: 10 }}>
                  Try one of these, or ask your own question:
                </p>
                {PROMPTS.map((p) => (
                  <SuggestedPrompt key={p} text={p} onClick={handleSend} />
                ))}
              </div>
            ) : (
              messages.map((m, i) => <ChatMessage key={i} role={m.role} content={m.content} />)
            )}

            {error && (
              <p style={{ color: 'var(--danger)', fontSize: 12.5, marginTop: 12 }}>{error}</p>
            )}
          </div>

          <ChatInput onSend={handleSend} disabled={sending} />
        </Card>

        {/* Side panel */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          <Card>
            <Eyebrow style={{ marginBottom: 12 }}>◆ Career focus</Eyebrow>
            <div style={{ fontSize: 13.5, marginBottom: 10 }}>
              {user?.careerGoal || 'Not set yet — add this from your Profile.'}
            </div>
            <div className="faint" style={{ fontSize: 11.5, marginBottom: 4 }}>Current strengths</div>
            <div style={{ fontSize: 13 }}>
              {user?.strengths?.length ? user.strengths.join(', ') : 'Not set yet'}
            </div>
          </Card>

          <Card>
            <Eyebrow style={{ marginBottom: 12 }}>◆ AI insight</Eyebrow>
            <p className="muted" style={{ fontSize: 12.5, lineHeight: 1.6 }}>
              Conversational insight will appear here once the mentor backend is connected —
              this panel is wired to render it, not to fabricate it in the meantime.
            </p>
          </Card>
        </div>
      </div>
    </AppShell>
  );
}
