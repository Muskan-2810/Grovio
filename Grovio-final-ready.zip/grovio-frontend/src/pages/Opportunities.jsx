import { useEffect, useMemo, useState } from 'react';
import { Search } from 'lucide-react';
import AppShell from '../components/layout/AppShell.jsx';
import Card from '../components/ui/Card.jsx';
import { Eyebrow } from '../components/ui/Misc.jsx';
import OpportunityCard from '../components/opportunities/OpportunityCard.jsx';
import { fetchOpportunities } from '../lib/opportunityService.js';

export default function Opportunities() {
  const [opportunities, setOpportunities] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const [query, setQuery] = useState('');
  const [type, setType] = useState('ALL');
  // Saved state is local-only — there's no backend bookmark endpoint yet
  // (see OpportunityCard.jsx), so this resets on refresh. Real, not mocked
  // data, just not persisted yet.
  const [savedIds, setSavedIds] = useState(new Set());

  useEffect(() => {
    let cancelled = false;
    fetchOpportunities()
      .then((data) => { if (!cancelled) setOpportunities(data); })
      .catch((err) => { if (!cancelled) setError(err.message || 'Could not load opportunities.'); })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, []);

  const types = useMemo(() => ['ALL', ...new Set(opportunities.map((o) => o.type))], [opportunities]);

  const filtered = useMemo(() => {
    return opportunities.filter((o) => {
      const matchesType = type === 'ALL' || o.type === type;
      const haystack = `${o.title} ${o.companyName} ${o.location ?? ''}`.toLowerCase();
      const matchesQuery = !query.trim() || haystack.includes(query.trim().toLowerCase());
      return matchesType && matchesQuery;
    });
  }, [opportunities, type, query]);

  const toggleSave = (id) => {
    setSavedIds((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  return (
    <AppShell title="Opportunity Hub" subtitle="Internships and jobs matched to your profile">
      {/* Search + filters — client-side over the real matched-opportunities
          response, since there's no dedicated search endpoint yet (role,
          experience, skills filters aren't backed by real fields on the
          Opportunity entity, so only title/company/location/type are
          genuinely filterable right now). */}
      <Card style={{ marginBottom: 20, padding: 16 }}>
        <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', alignItems: 'center' }}>
          <div className="glass" style={{ display: 'flex', alignItems: 'center', gap: 8, borderRadius: 10, padding: '9px 14px', flex: 1, minWidth: 220 }}>
            <Search size={15} color="var(--text-3)" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search by role, company, or location…"
              style={{ width: '100%', fontSize: 13 }}
            />
          </div>
          <select
            value={type}
            onChange={(e) => setType(e.target.value)}
            className="glass"
            style={{ borderRadius: 10, padding: '9px 14px', fontSize: 13, color: 'var(--text-1)' }}
          >
            {types.map((t) => (
              <option key={t} value={t} style={{ background: 'var(--surface)' }}>
                {t === 'ALL' ? 'All types' : t}
              </option>
            ))}
          </select>
        </div>
      </Card>

      {loading && <p className="muted" style={{ padding: '40px 0', textAlign: 'center' }}>Loading opportunities…</p>}

      {error && (
        <Card style={{ textAlign: 'center', padding: 30 }}>
          <p className="muted" style={{ fontSize: 13.5 }}>{error}</p>
        </Card>
      )}

      {!loading && !error && filtered.length === 0 && (
        <Card style={{ textAlign: 'center', padding: 30 }}>
          <Eyebrow style={{ justifyContent: 'center', marginBottom: 8 }}>◆ No matches</Eyebrow>
          <p className="muted" style={{ fontSize: 13.5 }}>
            {opportunities.length === 0 ? 'No opportunities matched to your profile yet.' : 'Nothing matches those filters.'}
          </p>
        </Card>
      )}

      {!loading && !error && filtered.length > 0 && (
        <div className="grid grid-3" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))' }}>
          {filtered.map((o) => (
            <OpportunityCard
              key={o.id}
              opportunity={o}
              saved={savedIds.has(o.id)}
              onToggleSave={() => toggleSave(o.id)}
            />
          ))}
        </div>
      )}
    </AppShell>
  );
}
