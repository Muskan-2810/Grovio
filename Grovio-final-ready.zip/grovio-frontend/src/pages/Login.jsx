import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';

export default function Login() {
  const navigate = useNavigate();
  const { login } = useAuth();
  const [form, setForm] = useState({ email: '', password: '' });
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(null);

  const handleChange = (e) => {
    setForm((f) => ({ ...f, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      await login(form);
      navigate('/dashboard');
    } catch (err) {
      setError(err.message || 'Login failed. Please check your credentials.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <section className="screen-enter" style={{ position: 'relative' }}>
      <div
        className="aura"
        style={{
          width: 480,
          height: 480,
          background: 'var(--purple)',
          top: '10%',
          left: '50%',
          transform: 'translateX(-50%)',
          opacity: 0.28,
        }}
      />
      <div
        style={{
          minHeight: 'calc(100vh - 52px)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          position: 'relative',
          zIndex: 2,
        }}
      >
        <div className="card fade-up" style={{ width: 400, padding: 36 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 9, marginBottom: 28 }}>
            <div style={{ width: 26, height: 26, borderRadius: 8, background: 'var(--grad)' }} />
            <span className="font-display" style={{ fontWeight: 500, fontSize: 18 }}>Grovio</span>
          </div>
          <h2 className="font-display" style={{ fontSize: 24, marginBottom: 6 }}>Welcome back</h2>
          <p className="muted" style={{ fontSize: 13.5, marginBottom: 26 }}>Your companion missed you.</p>

          <button
            type="button"
            className="btn-ghost btn"
            style={{ width: '100%', justifyContent: 'center', marginBottom: 18, opacity: 0.5, cursor: 'not-allowed' }}
            disabled
            title="Google sign-in isn't implemented yet"
          >
            Continue with Google (coming soon)
          </button>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 18 }}>
            <div className="hr" style={{ flex: 1 }} />
            <span className="faint" style={{ fontSize: 11.5 }}>or</span>
            <div className="hr" style={{ flex: 1 }} />
          </div>

          <form onSubmit={handleSubmit}>
            <label className="faint" style={{ fontSize: 11.5, textTransform: 'uppercase', letterSpacing: '.05em' }}>
              Email
            </label>
            <div className="glass" style={{ borderRadius: 10, padding: '11px 14px', margin: '6px 0 16px' }}>
              <input
                type="email"
                name="email"
                required
                value={form.email}
                onChange={handleChange}
                placeholder="you@college.edu"
                style={{ width: '100%', fontSize: 14 }}
              />
            </div>
            <label className="faint" style={{ fontSize: 11.5, textTransform: 'uppercase', letterSpacing: '.05em' }}>
              Password
            </label>
            <div className="glass" style={{ borderRadius: 10, padding: '11px 14px', margin: '6px 0 8px' }}>
              <input
                type="password"
                name="password"
                required
                value={form.password}
                onChange={handleChange}
                placeholder="••••••••"
                style={{ width: '100%', fontSize: 14 }}
              />
            </div>
            <div style={{ textAlign: 'right', marginBottom: 20 }}>
              <span className="faint" style={{ fontSize: 12, cursor: 'not-allowed', opacity: 0.6 }} title="Not implemented yet">
                Forgot password? (coming soon)
              </span>
            </div>

            {error && (
              <p style={{ color: 'var(--danger)', fontSize: 12.5, marginBottom: 14 }}>{error}</p>
            )}

            <button type="submit" className="btn btn-primary" style={{ width: '100%', justifyContent: 'center', opacity: submitting ? 0.7 : 1 }} disabled={submitting}>
              {submitting ? 'Logging in…' : 'Log in'}
            </button>
          </form>
          <p className="muted" style={{ textAlign: 'center', fontSize: 12.5, marginTop: 20 }}>
            New to Grovio?{' '}
            <a style={{ color: 'var(--purple-l)', fontWeight: 600, cursor: 'pointer' }} onClick={() => navigate('/onboarding')}>
              Create an account
            </a>
          </p>
        </div>
      </div>
    </section>
  );
}
