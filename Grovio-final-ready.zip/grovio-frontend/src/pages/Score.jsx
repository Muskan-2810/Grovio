import { useEffect, useState } from 'react';
import AppShell from '../components/layout/AppShell.jsx';
import Card from '../components/ui/Card.jsx';
import ProgressRing from '../components/ui/ProgressRing.jsx';
import { Eyebrow } from '../components/ui/Misc.jsx';
import CareerMetric from '../components/career/CareerMetric.jsx';
import { useAuth } from '../context/AuthContext.jsx';
import { fetchCareerProgress } from '../lib/careerScoreService.js';

const PROFILE_FIELDS = ['fullName', 'college', 'branch', 'graduationYear', 'careerGoal'];

// Real, computed from the actual logged-in user object — not fabricated.
function computeProfileCompleteness(user) {
  if (!user) return 0;
  const filled = PROFILE_FIELDS.filter((f) => Boolean(user[f])).length;
  const hasStrengths = user.strengths?.length > 0;
  return Math.round(((filled + (hasStrengths ? 1 : 0)) / (PROFILE_FIELDS.length + 1)) * 100);
}

export default function Score() {
  const { user } = useAuth();
  const [progress, setProgress] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    let cancelled = false;
    fetchCareerProgress()
      .then((data) => { if (!cancelled) setProgress(data); })
      .catch((err) => { if (!cancelled) setError(err.message || 'Could not load your score.'); })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, []);

  if (loading) {
    return (
      <AppShell title="Career Score">
        <p className="muted" style={{ padding: '60px 0', textAlign: 'center' }}>Loading your score…</p>
      </AppShell>
    );
  }

  if (error) {
    return (
      <AppShell title="Career Score">
        <Card style={{ textAlign: 'center', padding: 30 }}>
          <p className="muted" style={{ fontSize: 13.5 }}>{error}</p>
        </Card>
      </AppShell>
    );
  }

  const profileCompleteness = computeProfileCompleteness(user);
  // Consistency: how close current streak is to your own best — a real,
  // derived measure of "are you as consistent right now as your best run",
  // not an invented number.
  const consistency = progress.longestStreak > 0
    ? Math.round((progress.streakCount / progress.longestStreak) * 100)
    : 0;

  const nextBestAction = [...[
    { label: 'DSA', value: progress.dsaScore },
    { label: 'Resume', value: progress.resumeScore },
    { label: 'Projects', value: progress.projectsScore },
    { label: 'Aptitude & Interview Readiness', value: progress.aptitudeScore },
    { label: 'Communication', value: progress.communicationScore },
    { label: 'Profile completeness', value: profileCompleteness },
    { label: 'Consistency', value: consistency },
  ]].sort((a, b) => a.value - b.value)[0];

  return (
    <AppShell title="Career Score" subtitle="Your readiness, broken down">
      <div className="grid" style={{ gridTemplateColumns: '1fr 1.6fr', gap: 20, alignItems: 'start' }}>
        <Card style={{ textAlign: 'center' }}>
          <Eyebrow style={{ justifyContent: 'center', marginBottom: 16 }}>◆ Overall score</Eyebrow>
          <ProgressRing score={progress.overallScore} size={150} />
          {typeof progress.weeklyDelta === 'number' && (
            <p className="muted" style={{ fontSize: 12, marginTop: 12 }}>
              {progress.weeklyDelta >= 0 ? '↑' : '↓'} {Math.abs(progress.weeklyDelta)} points this week
            </p>
          )}
        </Card>

        <Card>
          <Eyebrow style={{ marginBottom: 16 }}>◆ Breakdown</Eyebrow>
          <CareerMetric label="DSA" value={progress.dsaScore} />
          <CareerMetric label="Resume" value={progress.resumeScore} />
          <CareerMetric label="Projects" value={progress.projectsScore} />
          <CareerMetric label="Aptitude & Interview Readiness" value={progress.aptitudeScore} />
          <CareerMetric label="Communication" value={progress.communicationScore} />
          <CareerMetric label="Profile completeness" value={profileCompleteness} />
          <CareerMetric label="Consistency" value={consistency} />
        </Card>
      </div>

      <Card style={{ marginTop: 20 }}>
        <Eyebrow style={{ marginBottom: 10 }}>◆ Your next best action</Eyebrow>
        <p style={{ fontSize: 14 }}>
          <strong>{nextBestAction.label}</strong> is your lowest-scoring area right now
          ({nextBestAction.value}%) — that's the highest-leverage place to spend time next.
        </p>
      </Card>
    </AppShell>
  );
}
