import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import AppShell from '../components/layout/AppShell.jsx';
import Card from '../components/ui/Card.jsx';
import Pill from '../components/ui/Pill.jsx';
import ProgressRing from '../components/ui/ProgressRing.jsx';
import { Eyebrow, MatchBar } from '../components/ui/Misc.jsx';
import { fetchDashboardSummary, fetchRecentActivity } from '../lib/dashboardService.js';

export default function Dashboard() {
  const [summary, setSummary] = useState(null);
  const [activity, setActivity] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    let cancelled = false;

    async function load() {
      setLoading(true);
      setError(null);
      try {
        // Independent requests — a slow/failed activity feed shouldn't
        // block the rest of a page that has nothing to do with it.
        const [summaryData, activityData] = await Promise.all([
          fetchDashboardSummary(),
          fetchRecentActivity(5).catch(() => []),
        ]);
        if (!cancelled) {
          setSummary(summaryData);
          setActivity(activityData);
        }
      } catch (err) {
        if (!cancelled) setError(err.message || 'Could not load your dashboard.');
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    load();
    return () => { cancelled = true; };
  }, []);

  if (loading) {
    return (
      <AppShell title="Dashboard" subtitle="Loading your data…">
        <div style={{ padding: '80px 0', textAlign: 'center', color: 'var(--text-2)' }}>
          Loading your dashboard…
        </div>
      </AppShell>
    );
  }

  if (error) {
    return (
      <AppShell title="Dashboard">
        <Card style={{ textAlign: 'center', padding: 40 }}>
          <div style={{ fontWeight: 600, marginBottom: 6 }}>Couldn't load the dashboard</div>
          <p className="muted" style={{ fontSize: 13.5, marginBottom: 18 }}>{error}</p>
          <button className="btn btn-primary" onClick={() => window.location.reload()}>
            Try again
          </button>
        </Card>
      </AppShell>
    );
  }

  const { progress, mentorInsight, todayMission, matchedOpportunities, matchedHackathons, weeklyPlan } = summary;
  const opportunities = [...(matchedOpportunities ?? []), ...(matchedHackathons ?? [])];

  return (
    <AppShell
      title="Dashboard"
      subtitle="Today"
      streak={progress?.streakCount}
      bestStreak={progress?.longestStreak}
    >
      {/* Mentor hero */}
      <Card fadeUp style={{ marginBottom: 20 }}>
        <Eyebrow style={{ marginBottom: 10 }}>◆ Your companion</Eyebrow>
        <p style={{ fontSize: 16, fontWeight: 500 }}>{mentorInsight}</p>
      </Card>

      <div className="grid grid-3" style={{ gridTemplateColumns: '1fr 1fr 1fr', marginBottom: 20 }}>
        {/* 1. Progress */}
        <Card fadeUp>
          <Link to="/score" style={{ display: 'block' }}>
            <Eyebrow style={{ marginBottom: 14 }}>◆ Career pulse</Eyebrow>
          </Link>
          <ProgressRing score={progress?.overallScore ?? 0} />
          {typeof progress?.weeklyDelta === 'number' && (
            <p className="muted" style={{ textAlign: 'center', fontSize: 12, marginTop: 10 }}>
              {progress.weeklyDelta >= 0 ? '↑' : '↓'} {Math.abs(progress.weeklyDelta)} this week
            </p>
          )}
        </Card>

        {/* 3. Today's mission */}
        <Card fadeUp style={{ gridColumn: 'span 2' }}>
          <Link to="/prep" style={{ display: 'block' }}>
            <Eyebrow style={{ marginBottom: 14 }}>◆ Today's mission</Eyebrow>
          </Link>
          {(!todayMission || todayMission.length === 0) ? (
            <p className="muted" style={{ fontSize: 13 }}>Nothing queued for today yet.</p>
          ) : (
            todayMission.map((task) => (
              <div key={task.id} style={{ display: 'flex', justifyContent: 'space-between', padding: '10px 0', borderBottom: '1px solid var(--border)' }}>
                <div>
                  <div style={{ fontSize: 13.5, fontWeight: 500, opacity: task.completed ? 0.5 : 1, textDecoration: task.completed ? 'line-through' : 'none' }}>
                    {task.title}
                  </div>
                  {task.insight && <div className="faint" style={{ fontSize: 11.5, marginTop: 3 }}>{task.insight}</div>}
                </div>
                {task.priorityLabel && <Pill tone="purple">{task.priorityLabel}</Pill>}
              </div>
            ))
          )}
        </Card>
      </div>

      <div className="grid grid-2" style={{ gridTemplateColumns: '1.3fr 1fr', marginBottom: 20 }}>
        {/* 2. Opportunities */}
        <Card fadeUp>
          <Link to="/opportunities" style={{ display: 'block' }}>
            <Eyebrow style={{ marginBottom: 14 }}>◆ Matched for you</Eyebrow>
          </Link>
          {opportunities.length === 0 ? (
            <p className="muted" style={{ fontSize: 13 }}>
              No matches yet — this fills in once your profile has enough signal to match against.
            </p>
          ) : (
            opportunities.map((o) => (
              <div key={o.id} style={{ padding: '12px 0', borderBottom: '1px solid var(--border)' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <div style={{ fontSize: 13.5, fontWeight: 600 }}>{o.companyName} · {o.title}</div>
                  <Pill tone="success">{o.matchPercent}% match</Pill>
                </div>
                <div className="faint" style={{ fontSize: 11.5, margin: '4px 0' }}>
                  {o.location} {o.compensationOrPrize ? `· ${o.compensationOrPrize}` : ''} · {o.daysLeft} day{o.daysLeft === 1 ? '' : 's'} left
                </div>
                <MatchBar percent={o.matchPercent} />
              </div>
            ))
          )}
        </Card>

        {/* 4. Weekly plan */}
        <Card fadeUp>
          <Eyebrow style={{ marginBottom: 14 }}>◆ This week's plan</Eyebrow>
          {(!weeklyPlan || weeklyPlan.length === 0) ? (
            <p className="muted" style={{ fontSize: 13 }}>No topics scheduled for this week yet.</p>
          ) : (
            weeklyPlan.map((t) => (
              <div key={t.id} style={{ marginBottom: 14 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13 }}>
                  <span>{t.topic}</span>
                  <span className="faint">{t.progressPercent}%</span>
                </div>
                <MatchBar percent={t.progressPercent} />
              </div>
            ))
          )}
        </Card>
      </div>

      {/* 5. Recent activity */}
      <Card fadeUp>
        <Eyebrow style={{ marginBottom: 14 }}>◆ Recent activity</Eyebrow>
        {(!activity || activity.length === 0) ? (
          <p className="muted" style={{ fontSize: 13 }}>Nothing logged yet — activity shows up here as you use Grovio.</p>
        ) : (
          activity.map((a) => (
            <div key={a.id} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', fontSize: 13 }}>
              <span>{a.description}</span>
              <span className="faint" style={{ fontSize: 11.5 }}>
                {new Date(a.createdAt).toLocaleDateString()}
              </span>
            </div>
          ))
        )}
      </Card>
    </AppShell>
  );
}
