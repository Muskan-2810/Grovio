import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';

const GOALS = ['Full-time placement', 'Internship', 'Both', 'Just exploring'];
const STRENGTHS = ['DSA', 'Java', 'SQL', 'Web Development', 'CS Fundamentals', 'Aptitude'];

export default function Onboarding() {
  const navigate = useNavigate();
  const { register, updateProfile } = useAuth();
  const [step, setStep] = useState(1);
  const totalSteps = 5;

  const [profile, setProfile] = useState({ name: '', email: '', password: '', college: '', branch: '', year: '' });
  const [goal, setGoal] = useState(null);
  const [strengths, setStrengths] = useState([]);
  const [resumeFile, setResumeFile] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(null);

  const toggleStrength = (s) => {
    setStrengths((prev) => (prev.includes(s) ? prev.filter((x) => x !== s) : [...prev, s]));
  };

  const handleProfileChange = (e) => {
    setProfile((p) => ({ ...p, [e.target.name]: e.target.value }));
  };

  const handleFileChange = (e) => {
    setResumeFile(e.target.files?.[0] ?? null);
    // TODO(API wiring phase): upload to POST /v1/resume/upload once authenticated
  };

  const goNext = () => setStep((s) => Math.min(totalSteps, s + 1));
  const goBack = () => setStep((s) => Math.max(1, s - 1));

  const finishOnboarding = async () => {
    setError(null);
    setSubmitting(true);
    try {
      await register({
        fullName: profile.name,
        email: profile.email,
        password: profile.password,
        college: profile.college,
        branch: profile.branch,
        graduationYear: parseInt(profile.year, 10) || new Date().getFullYear(),
      });

      // Register only accepts account-creation fields — goal and strengths
      // are a separate write via the profile endpoint, now that we have a
      // token to authenticate the request with.
      if (goal || strengths.length > 0) {
        await updateProfile({ careerGoal: goal, strengths });
      }

      // TODO(Resume module): once /v1/resume/upload exists, upload resumeFile here if present.
      navigate('/dashboard');
    } catch (err) {
      setError(err.message || 'Something went wrong creating your account.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <section className="screen-enter" style={{ position: 'relative' }}>
      <div
        className="aura"
        style={{ width: 460, height: 460, background: 'var(--blue)', top: -100, right: -100, opacity: 0.25 }}
      />
      <div style={{ maxWidth: 560, margin: '0 auto', padding: '60px 24px', position: 'relative', zIndex: 2 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 9, marginBottom: 34 }}>
          <div style={{ width: 26, height: 26, borderRadius: 8, background: 'var(--grad)' }} />
          <span className="font-display" style={{ fontWeight: 500, fontSize: 18 }}>Grovio</span>
        </div>

        {/* progress dots */}
        <div style={{ display: 'flex', gap: 6, marginBottom: 30 }}>
          {Array.from({ length: totalSteps }, (_, i) => i + 1).map((dot) => (
            <div
              key={dot}
              style={{
                height: 4,
                flex: 1,
                borderRadius: 4,
                background: dot <= step ? 'var(--purple-l)' : 'var(--border)',
              }}
            />
          ))}
        </div>

        {/* Step 1: basic profile */}
        {step === 1 && (
          <div>
            <div className="eyebrow" style={{ marginBottom: 10 }}>◆ Step 1 of 5</div>
            <h2 className="font-display" style={{ fontSize: 26, marginBottom: 8 }}>
              Hey, I'm your Grovio companion.
            </h2>
            <p className="muted" style={{ marginBottom: 26 }}>Let's get you set up — takes about two minutes.</p>

            <label className="faint" style={{ fontSize: 11.5, textTransform: 'uppercase' }}>Your name</label>
            <div className="glass" style={{ borderRadius: 10, padding: '12px 14px', margin: '6px 0 16px' }}>
              <input
                name="name"
                value={profile.name}
                onChange={handleProfileChange}
                placeholder="Aditi Sharma"
                style={{ width: '100%', fontSize: 14 }}
              />
            </div>
            <label className="faint" style={{ fontSize: 11.5, textTransform: 'uppercase' }}>College</label>
            <div className="glass" style={{ borderRadius: 10, padding: '12px 14px', margin: '6px 0 16px' }}>
              <input
                name="college"
                value={profile.college}
                onChange={handleProfileChange}
                placeholder="e.g. VIT Bhopal"
                style={{ width: '100%', fontSize: 14 }}
              />
            </div>
            <label className="faint" style={{ fontSize: 11.5, textTransform: 'uppercase' }}>Email</label>
            <div className="glass" style={{ borderRadius: 10, padding: '12px 14px', margin: '6px 0 16px' }}>
              <input
                type="email"
                name="email"
                value={profile.email}
                onChange={handleProfileChange}
                placeholder="you@college.edu"
                style={{ width: '100%', fontSize: 14 }}
              />
            </div>
            <label className="faint" style={{ fontSize: 11.5, textTransform: 'uppercase' }}>Password</label>
            <div className="glass" style={{ borderRadius: 10, padding: '12px 14px', margin: '6px 0 16px' }}>
              <input
                type="password"
                name="password"
                value={profile.password}
                onChange={handleProfileChange}
                placeholder="At least 8 characters"
                style={{ width: '100%', fontSize: 14 }}
              />
            </div>
            <div style={{ display: 'flex', gap: 12 }}>
              <div style={{ flex: 1 }}>
                <label className="faint" style={{ fontSize: 11.5, textTransform: 'uppercase' }}>Branch</label>
                <div className="glass" style={{ borderRadius: 10, padding: '12px 14px', margin: '6px 0 16px' }}>
                  <input
                    name="branch"
                    value={profile.branch}
                    onChange={handleProfileChange}
                    placeholder="CSE"
                    style={{ width: '100%', fontSize: 14 }}
                  />
                </div>
              </div>
              <div style={{ flex: 1 }}>
                <label className="faint" style={{ fontSize: 11.5, textTransform: 'uppercase' }}>Graduation Year</label>
                <div className="glass" style={{ borderRadius: 10, padding: '12px 14px', margin: '6px 0 16px' }}>
                  <input
                    name="year"
                    value={profile.year}
                    onChange={handleProfileChange}
                    placeholder="2027"
                    style={{ width: '100%', fontSize: 14 }}
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Step 2: goal */}
        {step === 2 && (
          <div>
            <div className="eyebrow" style={{ marginBottom: 10 }}>◆ Step 2 of 5</div>
            <h2 className="font-display" style={{ fontSize: 26, marginBottom: 8 }}>What are you aiming for?</h2>
            <p className="muted" style={{ marginBottom: 26 }}>This shapes everything I show you.</p>
            <div className="grid" style={{ gridTemplateColumns: '1fr 1fr', gap: 12 }}>
              {GOALS.map((g, i) => (
                <div
                  key={g}
                  className="card"
                  style={{
                    cursor: 'pointer',
                    padding: 20,
                    borderColor: goal === g ? 'var(--accent)' : undefined,
                    background: goal === g ? 'var(--surface-hi)' : undefined,
                  }}
                  onClick={() => setGoal(g)}
                >
                  <div className="mark-num">{String(i + 1).padStart(2, '0')}</div>
                  <div style={{ fontWeight: 600, marginTop: 8 }}>{g}</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Step 3: strengths */}
        {step === 3 && (
          <div>
            <div className="eyebrow" style={{ marginBottom: 10 }}>◆ Step 3 of 5</div>
            <h2 className="font-display" style={{ fontSize: 26, marginBottom: 8 }}>
              Where are you strongest right now?
            </h2>
            <p className="muted" style={{ marginBottom: 26 }}>
              No wrong answers — just a starting point. Pick as many as fit.
            </p>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10 }}>
              {STRENGTHS.map((s) => (
                <span
                  key={s}
                  className={`pill ${strengths.includes(s) ? 'purple' : ''}`}
                  style={{ cursor: 'pointer', padding: '10px 16px', fontSize: 13 }}
                  onClick={() => toggleStrength(s)}
                >
                  {s}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Step 4: resume upload (optional) */}
        {step === 4 && (
          <div>
            <div className="eyebrow" style={{ marginBottom: 10 }}>◆ Step 4 of 5</div>
            <h2 className="font-display" style={{ fontSize: 26, marginBottom: 8 }}>Got a resume?</h2>
            <p className="muted" style={{ marginBottom: 26 }}>
              Optional — I can use it as a shortcut, or we build your profile together as you go.
            </p>
            <label htmlFor="resume-upload" style={{ display: 'block', cursor: 'pointer' }}>
              <div
                className="glass"
                style={{ borderRadius: 14, border: '1.5px dashed var(--border-hi)', padding: 38, textAlign: 'center' }}
              >
                <div className="mark-circle" style={{ margin: '0 auto 14px' }}>CV</div>
                <div style={{ fontWeight: 600, marginBottom: 4 }}>
                  {resumeFile ? resumeFile.name : 'Drop your resume here'}
                </div>
                <div className="faint" style={{ fontSize: 12.5 }}>PDF, up to 5MB</div>
              </div>
            </label>
            <input
              id="resume-upload"
              type="file"
              accept="application/pdf"
              onChange={handleFileChange}
              style={{ display: 'none' }}
            />
            <p style={{ textAlign: 'center', marginTop: 16 }}>
              <a className="muted" style={{ fontSize: 13, cursor: 'pointer' }} onClick={goNext}>
                Skip for now →
              </a>
            </p>
          </div>
        )}

        {/* Step 5: summary */}
        {step === 5 && (
          <div>
            <div className="eyebrow" style={{ marginBottom: 10 }}>◆ You're set</div>
            <h2 className="font-display" style={{ fontSize: 26, marginBottom: 8 }}>Here's your first week.</h2>
            <p className="muted" style={{ marginBottom: 22 }}>
              I've put together a starting plan based on what you told me.
            </p>
            <div className="card" style={{ marginBottom: 12, padding: 18 }}>
              <div className="eyebrow" style={{ marginBottom: 8 }}>◆ This week</div>
              <div style={{ fontSize: 14, marginBottom: 6 }}>→ Finish the Recursion module (4 problems left)</div>
              <div style={{ fontSize: 14, marginBottom: 6 }}>→ Review 3 matched internships closing this week</div>
              <div style={{ fontSize: 14 }}>→ 15-min chat with your mentor to set target companies</div>
            </div>
            {error && (
              <p style={{ color: 'var(--danger)', fontSize: 12.5, marginBottom: 14 }}>{error}</p>
            )}
            <button
              className="btn btn-primary"
              style={{ width: '100%', justifyContent: 'center', opacity: submitting ? 0.7 : 1 }}
              onClick={finishOnboarding}
              disabled={submitting}
            >
              {submitting ? 'Setting things up…' : 'Enter Grovio →'}
            </button>
          </div>
        )}

        {/* wizard nav (hidden on final step, which has its own CTA) */}
        {step < 5 && (
          <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 28 }}>
            <button className="btn btn-ghost" style={{ visibility: step === 1 ? 'hidden' : 'visible' }} onClick={goBack}>
              Back
            </button>
            <button className="btn btn-primary" onClick={goNext}>
              Continue →
            </button>
          </div>
        )}
      </div>
    </section>
  );
}
