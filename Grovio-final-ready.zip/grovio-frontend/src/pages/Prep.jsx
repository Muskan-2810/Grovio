import { useState } from 'react';
import AppShell from '../components/layout/AppShell.jsx';
import Card from '../components/ui/Card.jsx';
import Pill from '../components/ui/Pill.jsx';
import { Eyebrow } from '../components/ui/Misc.jsx';
import TopicCard from '../components/preparation/TopicCard.jsx';
import ProgressCard from '../components/preparation/ProgressCard.jsx';

// No dedicated "DSA topic progress" backend endpoint exists yet (Dashboard's
// weeklyPlan is the closest real signal, and it only covers 2-3 topics at a
// time, not a fixed DSA curriculum). Rather than invent fake per-topic
// percentages, topics are shown as a real, fixed curriculum with progress
// left at 0 until a real "DSA Revision Hub" endpoint exists to back it —
// this is UI-only structure, not fabricated activity.
const DSA_TOPICS = [
  { title: 'Arrays', difficulty: 'Easy' },
  { title: 'Strings', difficulty: 'Easy' },
  { title: 'Linked Lists', difficulty: 'Medium' },
  { title: 'Trees', difficulty: 'Medium' },
  { title: 'Graphs', difficulty: 'Hard' },
  { title: 'Dynamic Programming', difficulty: 'Hard' },
  { title: 'Greedy', difficulty: 'Medium' },
];

const INTERVIEW_TRACKS = [
  { title: 'Coding Interviews', difficulty: 'Medium' },
  { title: 'Technical Interviews', difficulty: 'Medium' },
  { title: 'HR / Behavioral Interviews', difficulty: 'Easy' },
  { title: 'Company-specific Preparation', difficulty: 'Hard' },
];

export default function Prep() {
  const [section, setSection] = useState('dsa');
  const topics = section === 'dsa' ? DSA_TOPICS : INTERVIEW_TRACKS;

  return (
    <AppShell title="Preparation Hub" subtitle="DSA and interview readiness, in one place">
      <ProgressCard
        overallPercent={0}
        completedCount={0}
        totalCount={DSA_TOPICS.length + INTERVIEW_TRACKS.length}
        currentTopic={null}
        nextTopic={DSA_TOPICS[0].title}
      />

      <div style={{ display: 'flex', gap: 10, margin: '20px 0' }}>
        <Pill
          tone={section === 'dsa' ? 'purple' : undefined}
          as="button"
          style={{ cursor: 'pointer' }}
          onClick={() => setSection('dsa')}
        >
          DSA
        </Pill>
        <Pill
          tone={section === 'interview' ? 'purple' : undefined}
          as="button"
          style={{ cursor: 'pointer' }}
          onClick={() => setSection('interview')}
        >
          Interview Preparation
        </Pill>
      </div>

      <Card style={{ marginBottom: 20, padding: 18 }}>
        <Eyebrow>◆ No topic-level backend data yet</Eyebrow>
        <p className="muted" style={{ fontSize: 12.5, marginTop: 6 }}>
          These topics are a real, fixed curriculum — progress will populate once a DSA
          Revision Hub endpoint exists to track solved problems per topic.
        </p>
      </Card>

      <div className="grid grid-3" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))' }}>
        {topics.map((t) => (
          <TopicCard
            key={t.title}
            title={t.title}
            difficulty={t.difficulty}
            progressPercent={0}
            onContinue={() => {}}
          />
        ))}
      </div>
    </AppShell>
  );
}
