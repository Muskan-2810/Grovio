import { useState } from 'react';
import { UploadCloud, Sparkles } from 'lucide-react';
import AppShell from '../components/layout/AppShell.jsx';
import Card from '../components/ui/Card.jsx';
import { Eyebrow } from '../components/ui/Misc.jsx';
import { uploadResume, fetchResumeAnalysis } from '../lib/resumeService.js';

export default function Resume() {
  const [file, setFile] = useState(null);
  const [status, setStatus] = useState('idle'); // idle | analyzing | error
  const [error, setError] = useState(null);

  const handleFileChange = (e) => {
    setFile(e.target.files?.[0] ?? null);
    setStatus('idle');
    setError(null);
  };

  const handleAnalyze = async () => {
    if (!file) return;
    setStatus('analyzing');
    setError(null);
    try {
      const uploaded = await uploadResume(file);
      await fetchResumeAnalysis(uploaded.resumeId);
      // Unreachable until the backend exists — both calls above throw.
    } catch (err) {
      setStatus('error');
      setError(err.message || 'Resume analysis is not available yet.');
    }
  };

  return (
    <AppShell title="Resume Intelligence" subtitle="Upload your resume for AI-powered feedback">
      <div className="grid" style={{ gridTemplateColumns: '1fr 1fr', gap: 20, alignItems: 'start' }}>
        {/* Upload area */}
        <Card>
          <Eyebrow style={{ marginBottom: 14 }}>◆ Upload resume</Eyebrow>
          <label htmlFor="resume-file" style={{ display: 'block', cursor: 'pointer' }}>
            <div className="glass" style={{ borderRadius: 14, border: '1.5px dashed var(--border-hi)', padding: 34, textAlign: 'center' }}>
              <UploadCloud size={26} color="var(--accent)" style={{ marginBottom: 10 }} />
              <div style={{ fontWeight: 600, marginBottom: 4, fontSize: 13.5 }}>
                {file ? file.name : 'Click to choose a file'}
              </div>
              <div className="faint" style={{ fontSize: 11.5 }}>PDF or DOCX, up to 5MB</div>
            </div>
          </label>
          <input id="resume-file" type="file" accept=".pdf,.doc,.docx" onChange={handleFileChange} style={{ display: 'none' }} />

          <button
            className="btn btn-primary"
            style={{ width: '100%', justifyContent: 'center', marginTop: 16, opacity: !file || status === 'analyzing' ? 0.6 : 1 }}
            onClick={handleAnalyze}
            disabled={!file || status === 'analyzing'}
          >
            <Sparkles size={15} /> {status === 'analyzing' ? 'Analyzing…' : 'Analyze resume'}
          </button>

          {status === 'error' && (
            <p style={{ color: 'var(--danger)', fontSize: 12.5, marginTop: 12 }}>{error}</p>
          )}
        </Card>

        {/* Analysis area */}
        <Card>
          <Eyebrow style={{ marginBottom: 14 }}>◆ Analysis</Eyebrow>
          {status !== 'error' && (
            <p className="muted" style={{ fontSize: 13, lineHeight: 1.6 }}>
              Resume analysis isn't connected to a backend yet — there's no upload or
              scoring endpoint on the server. This page is fully built and will show a
              real ATS score, strengths, weaknesses, and missing keywords the moment
              that endpoint exists. Nothing here is a placeholder score.
            </p>
          )}
          {status === 'error' && (
            <p className="muted" style={{ fontSize: 13 }}>
              Upload was attempted, but the backend rejected it because the endpoint
              doesn't exist yet — see the error on the left.
            </p>
          )}
        </Card>
      </div>
    </AppShell>
  );
}
