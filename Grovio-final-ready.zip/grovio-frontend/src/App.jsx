import { Routes, Route, Navigate } from 'react-router-dom';
import Landing from './pages/Landing.jsx';
import Login from './pages/Login.jsx';
import Onboarding from './pages/Onboarding.jsx';
import Dashboard from './pages/Dashboard.jsx';
import Mentor from './pages/Mentor.jsx';
import Prep from './pages/Prep.jsx';
import Opportunities from './pages/Opportunities.jsx';
import Resume from './pages/Resume.jsx';
import Score from './pages/Score.jsx';
import Profile from './pages/Profile.jsx';
import ProtectedRoute from './components/ProtectedRoute.jsx';

function protect(element) {
  return <ProtectedRoute>{element}</ProtectedRoute>;
}

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Landing />} />
      <Route path="/login" element={<Login />} />
      <Route path="/onboarding" element={<Onboarding />} />
      <Route path="/dashboard" element={protect(<Dashboard />)} />
      <Route path="/mentor" element={protect(<Mentor />)} />
      <Route path="/prep" element={protect(<Prep />)} />
      <Route path="/opportunities" element={protect(<Opportunities />)} />
      <Route path="/resume" element={protect(<Resume />)} />
      <Route path="/score" element={protect(<Score />)} />
      <Route path="/profile" element={protect(<Profile />)} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
