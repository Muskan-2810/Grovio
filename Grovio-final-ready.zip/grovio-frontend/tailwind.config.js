/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        bg: '#0B0B0B',
        'bg-elev': '#101010',
        'bg-elev-2': '#141414',
        surface: '#141414',
        'surface-hi': '#1B1B1B',
        border: '#2A2A2A',
        'border-hi': '#3A3A3A',
        'text-1': '#F8F8F5',
        'text-2': '#B8B8B5',
        'text-3': '#7A7A76',
        accent: '#D7C3A3',
        'accent-hover': '#CDB18A',
        success: '#4CAF50',
        warning: '#F4B400',
        danger: '#E53935',
      },
      fontFamily: {
        display: ['Fraunces', 'serif'],
        sans: ['Inter', 'sans-serif'],
        mono: ['JetBrains Mono', 'monospace'],
      },
      borderRadius: {
        DEFAULT: '14px',
        sm: '9px',
      },
      boxShadow: {
        card: '0 24px 60px -24px rgba(0,0,0,0.6)',
      },
    },
  },
  plugins: [],
};
