# Grovio Backend

Spring Boot 3 / Java 21 backend for Grovio. Currently implements: Authentication (register/login/me) secured with JWT + BCrypt, and Dashboard (aggregated progress/opportunities/mission/activity data for the logged-in student).

## Stack
- Java 21, Spring Boot 3.3.5, Maven
- Spring Security (stateless, JWT-based)
- Spring Data JPA / Hibernate
- PostgreSQL (Neon in production)
- JJWT 0.12.x for token generation/validation
- Lombok

## Project structure
```
src/main/java/com/grovio/backend/
  config/       SecurityConfig, CorsConfig
  controller/   AuthController, DashboardController, ProfileController, HealthController
  dto/          request/ (RegisterRequest, LoginRequest), response/ (per-module response DTOs)
  entity/       User, UserProgress, MissionTask, WeeklyPlanTopic, WatchlistItem,
                Opportunity, OpportunityMatch, TrendingCompany, ActivityLog
  repository/   one Spring Data repository per entity
  security/     JwtUtil, JwtAuthenticationFilter, CustomUserDetailsService
  service/      AuthService, DashboardService (+ impl/)
  exception/    GlobalExceptionHandler + custom exceptions
  util/         ApiResponse, ApiError (standard response envelopes)
```

## Local setup

1. **Create a database** (local Postgres or a free Neon project) named `grovio`.
2. **Set the required environment variables.** There are no working defaults committed for secrets — the app will fail to start without them, on purpose. Copy `.env.example`, fill in real values, then export them before running, e.g.:
   ```bash
   export DATABASE_URL=jdbc:postgresql://localhost:5432/grovio
   export DATABASE_USERNAME=postgres
   export DATABASE_PASSWORD=<your local postgres password>
   export JWT_SECRET=$(openssl rand -base64 64)
   export CORS_ALLOWED_ORIGINS=http://localhost:5173
   ```
   (Most IDEs also let you set these in the run configuration instead of exporting them in a shell.)
3. **Run:**
   ```bash
   mvn clean compile   # verify it builds
   mvn spring-boot:run
   ```
   The app starts on `http://localhost:8080`. Hibernate auto-creates all tables on first run (`ddl-auto=update`). `src/main/resources/sql/schema.sql` is the reference schema if you'd rather create it manually.

## Endpoints

| Method | Path | Auth | Description |
|---|---|---|---|
| POST | `/api/auth/register` | Public | Create account, returns JWT + user |
| POST | `/api/auth/login` | Public | Authenticate, returns JWT + user |
| GET | `/api/auth/me` | Bearer token | Returns the logged-in user's profile |
| GET | `/api/profile/me` | Bearer token | Same data as `/api/auth/me` (see "Known issues" — to be resolved in Phase 2) |
| GET | `/api/dashboard` | Bearer token | Aggregated dashboard payload (progress, mission, opportunities, weekly plan, watchlist, trending, mentor insight) |
| GET | `/api/dashboard/progress` | Bearer token | Career readiness score + streak |
| GET | `/api/dashboard/activity` | Bearer token | Recent activity feed |
| GET | `/api/dashboard/opportunities` | Bearer token | Matched opportunities + hackathons |
| GET | `/api/dashboard/learning` | Bearer token | This week's plan / continue learning |
| GET | `/api/health` | Public | Health check (used by Render) |

### Example — Register
```
POST /api/auth/register
Content-Type: application/json

{
  "fullName": "Aditi Sharma",
  "email": "aditi@example.com",
  "password": "StrongPass123",
  "college": "VIT Bhopal",
  "branch": "CSE",
  "graduationYear": 2027
}
```

### Example — Login
```
POST /api/auth/login
Content-Type: application/json

{
  "email": "aditi@example.com",
  "password": "StrongPass123"
}
```

Both return:
```json
{
  "success": true,
  "timestamp": "...",
  "data": {
    "accessToken": "eyJ...",
    "tokenType": "Bearer",
    "expiresIn": 3600,
    "user": { "id": 1, "fullName": "...", "email": "...", "college": "...", "branch": "...", "graduationYear": 2027, "profilePicture": null }
  }
}
```

## Deployment (Render)
- Build command: `mvn clean package -DskipTests`
- Start command: `java -jar target/grovio-backend.jar`
- Set the same environment variables listed above in Render's dashboard (use your Neon connection string for `DATABASE_URL`, and set `CORS_ALLOWED_ORIGINS` to your Vercel frontend URL).
