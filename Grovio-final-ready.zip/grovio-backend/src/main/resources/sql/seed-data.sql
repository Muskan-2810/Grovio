-- ==========================================================
-- OPTIONAL seed data for local development.
-- Not auto-executed. Run manually against your dev DB after
-- registering a test user, e.g.:
--   psql $DATABASE_URL -f seed-data.sql
--
-- Replace the :user_id placeholder with the real id of the user
-- you registered via POST /api/auth/register.
-- ==========================================================

-- Career pulse / progress
INSERT INTO user_progress (user_id, overall_score, resume_score, dsa_score, projects_score, aptitude_score, communication_score, weekly_delta, streak_count, longest_streak, last_active_date)
VALUES (:user_id, 72, 61, 85, 74, 58, 66, 4, 6, 21, CURRENT_DATE)
ON CONFLICT (user_id) DO NOTHING;

-- Today's mission
INSERT INTO mission_tasks (user_id, title, category, duration_minutes, priority_label, insight, completed, mission_date, display_order) VALUES
(:user_id, 'Recursion — Pattern 4: Backtracking basics', 'DSA', 18, 'Priority 1', 'Weak in your last 3 attempts, and it''s asked in 6 of your target companies'' sheets.', FALSE, CURRENT_DATE, 1),
(:user_id, 'Apply — Razorpay SDE Internship', 'OPPORTUNITY', NULL, 'Deadline', '92% skills match — the highest-fit role in your feed this month.', FALSE, CURRENT_DATE, 2),
(:user_id, 'Tighten one resume bullet — Chat App project', 'RESUME', 8, 'Quick win', 'Fastest lever on your readiness score right now — bigger impact than another DSA problem today.', FALSE, CURRENT_DATE, 3);

-- This week's plan / continue learning
INSERT INTO weekly_plan_topics (user_id, topic, progress_percent, insight, week_start_date, display_order) VALUES
(:user_id, 'Recursion & Backtracking', 82, 'Prioritized — appears in 6 of your target company sheets.', date_trunc('week', CURRENT_DATE)::date, 1),
(:user_id, 'SQL Joins & Subqueries', 45, 'Your slowest-improving topic over the last 2 weeks — added extra reps.', date_trunc('week', CURRENT_DATE)::date, 2),
(:user_id, 'System Design basics', 12, 'Introduced this week — Amazon''s sheet leans on it more than your other targets.', date_trunc('week', CURRENT_DATE)::date, 3);

-- Mentor's watchlist
INSERT INTO watchlist_items (user_id, title, insight, due_in_days, urgency_level, display_order) VALUES
(:user_id, 'Razorpay Internship', 'Top match — apply before anything else today.', 1, 'HIGH', 1),
(:user_id, 'Mock Interview — Fri', 'Booked based on your Amazon timeline.', 3, 'MEDIUM', 2),
(:user_id, 'HackVerse 3.0 registration', 'Low urgency — worth a slot once this week''s mission is done.', 6, 'LOW', 3);

-- Opportunities catalog
INSERT INTO opportunities (company_name, company_initials, title, type, location, compensation_or_prize, deadline, apply_url) VALUES
('Razorpay', 'RZ', 'SDE Intern', 'INTERNSHIP', 'Remote', '₹50,000/mo', CURRENT_DATE + INTERVAL '1 day', 'https://razorpay.com/careers'),
('Zoho', 'ZO', 'Associate SWE', 'JOB', 'Chennai', '₹8.2 LPA', CURRENT_DATE + INTERVAL '5 day', 'https://zoho.com/careers'),
('HackVerse', 'HV', 'HackVerse 3.0', 'HACKATHON', 'Online', '₹2L prize pool', CURRENT_DATE + INTERVAL '6 day', 'https://hackverse.example'),
('Smart Bharat', 'SB', 'Smart Bharat Hackathon', 'HACKATHON', 'Hybrid', 'Govt. sponsored', CURRENT_DATE + INTERVAL '12 day', 'https://smartbharat.example');

-- Matches for the seeded user (opportunity_id values assume a fresh DB — adjust if needed)
INSERT INTO opportunity_matches (user_id, opportunity_id, match_percent, match_reason, display_order)
SELECT :user_id, id, 92, '92% match — your DSA + SQL skills line up closely.', 1 FROM opportunities WHERE company_name = 'Razorpay';
INSERT INTO opportunity_matches (user_id, opportunity_id, match_percent, match_reason, display_order)
SELECT :user_id, id, 78, '78% match — strong on CS fundamentals, light on their SQL bar.', 2 FROM opportunities WHERE company_name = 'Zoho';
INSERT INTO opportunity_matches (user_id, opportunity_id, match_percent, match_reason, display_order)
SELECT :user_id, id, 88, 'Matches your web + AI interests — and you have zero hackathon lines on your resume.', 1 FROM opportunities WHERE company_name = 'HackVerse';
INSERT INTO opportunity_matches (user_id, opportunity_id, match_percent, match_reason, display_order)
SELECT :user_id, id, 64, 'Good fit, but timing overlaps your Amazon prep window — I''d deprioritize.', 2 FROM opportunities WHERE company_name = 'Smart Bharat';

-- Trending companies (global, no user_id)
INSERT INTO trending_companies (name, trend_label, display_order) VALUES
('Amazon', '+18% postings ↑', 1),
('TCS', 'Bulk hiring open', 2),
('Zoho', '92% you-match', 3),
('Razorpay', 'Closing soon', 4),
('Deloitte', 'New grad track', 5),
('Infosys', 'Bulk hiring open', 6),
('Atlassian', 'High bar, high fit', 7),
('Swiggy', 'Backend focus', 8);

-- Recent activity
INSERT INTO activity_logs (user_id, activity_type, description) VALUES
(:user_id, 'DSA_SOLVED', 'Solved 3 recursion problems'),
(:user_id, 'STREAK', 'Extended streak to 6 days'),
(:user_id, 'RESUME_UPDATED', 'Updated Chat App project bullet');
