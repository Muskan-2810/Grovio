-- ==========================================================
-- Grovio — Module 1: Authentication
-- Reference SQL schema for PostgreSQL / Neon.
--
-- NOTE: Hibernate (spring.jpa.hibernate.ddl-auto=update) will create/update
-- this table automatically from the User entity in development. This file
-- is provided as the authoritative reference schema, and as the starting
-- point for a Flyway/Liquibase migration once ddl-auto is switched to
-- "validate" for production.
-- ==========================================================

CREATE TABLE IF NOT EXISTS users (
    id                BIGSERIAL PRIMARY KEY,
    full_name         VARCHAR(100)        NOT NULL,
    email             VARCHAR(255)        NOT NULL UNIQUE,
    password          VARCHAR(255)        NOT NULL,
    college           VARCHAR(255),
    branch            VARCHAR(100),
    graduation_year   INTEGER,
    career_goal       VARCHAR(100),
    strengths         VARCHAR(500),
    profile_picture   VARCHAR(500),
    role              VARCHAR(20)         NOT NULL DEFAULT 'STUDENT',
    created_at        TIMESTAMP           NOT NULL DEFAULT NOW(),
    updated_at        TIMESTAMP           NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_users_email ON users (email);

-- ==========================================================
-- Module 2: Dashboard
-- ==========================================================

CREATE TABLE IF NOT EXISTS user_progress (
    id                    BIGSERIAL PRIMARY KEY,
    user_id               BIGINT NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
    overall_score         INTEGER NOT NULL DEFAULT 0,
    resume_score          INTEGER NOT NULL DEFAULT 0,
    dsa_score             INTEGER NOT NULL DEFAULT 0,
    projects_score        INTEGER NOT NULL DEFAULT 0,
    aptitude_score        INTEGER NOT NULL DEFAULT 0,
    communication_score   INTEGER NOT NULL DEFAULT 0,
    weekly_delta          INTEGER NOT NULL DEFAULT 0,
    streak_count          INTEGER NOT NULL DEFAULT 0,
    longest_streak        INTEGER NOT NULL DEFAULT 0,
    last_active_date      DATE,
    updated_at            TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS mission_tasks (
    id                BIGSERIAL PRIMARY KEY,
    user_id           BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title             VARCHAR(255) NOT NULL,
    category          VARCHAR(50)  NOT NULL,
    duration_minutes  INTEGER,
    priority_label    VARCHAR(50),
    insight           VARCHAR(500),
    completed         BOOLEAN NOT NULL DEFAULT FALSE,
    mission_date      DATE NOT NULL,
    display_order     INTEGER
);
CREATE INDEX IF NOT EXISTS idx_mission_tasks_user_date ON mission_tasks (user_id, mission_date);

CREATE TABLE IF NOT EXISTS weekly_plan_topics (
    id                BIGSERIAL PRIMARY KEY,
    user_id           BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    topic             VARCHAR(255) NOT NULL,
    progress_percent  INTEGER NOT NULL DEFAULT 0,
    insight           VARCHAR(500),
    week_start_date   DATE NOT NULL,
    display_order     INTEGER
);
CREATE INDEX IF NOT EXISTS idx_weekly_plan_user_week ON weekly_plan_topics (user_id, week_start_date);

CREATE TABLE IF NOT EXISTS watchlist_items (
    id             BIGSERIAL PRIMARY KEY,
    user_id        BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title          VARCHAR(255) NOT NULL,
    insight        VARCHAR(500),
    due_in_days    INTEGER,
    urgency_level  VARCHAR(20) NOT NULL,
    display_order  INTEGER
);

CREATE TABLE IF NOT EXISTS opportunities (
    id                     BIGSERIAL PRIMARY KEY,
    company_name           VARCHAR(255) NOT NULL,
    company_initials       VARCHAR(5),
    title                  VARCHAR(255) NOT NULL,
    type                   VARCHAR(20)  NOT NULL, -- INTERNSHIP, JOB, HACKATHON
    location               VARCHAR(255),
    compensation_or_prize  VARCHAR(100),
    deadline               DATE NOT NULL,
    apply_url              VARCHAR(500),
    created_at             TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS opportunity_matches (
    id               BIGSERIAL PRIMARY KEY,
    user_id          BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    opportunity_id   BIGINT NOT NULL REFERENCES opportunities(id) ON DELETE CASCADE,
    match_percent    INTEGER NOT NULL,
    match_reason     VARCHAR(500),
    display_order    INTEGER
);
CREATE INDEX IF NOT EXISTS idx_opp_matches_user ON opportunity_matches (user_id);

CREATE TABLE IF NOT EXISTS trending_companies (
    id             BIGSERIAL PRIMARY KEY,
    name           VARCHAR(255) NOT NULL,
    trend_label    VARCHAR(100) NOT NULL,
    display_order  INTEGER
);

CREATE TABLE IF NOT EXISTS activity_logs (
    id             BIGSERIAL PRIMARY KEY,
    user_id        BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    activity_type  VARCHAR(50) NOT NULL,
    description    VARCHAR(500) NOT NULL,
    created_at     TIMESTAMP NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_activity_logs_user ON activity_logs (user_id, created_at DESC);
