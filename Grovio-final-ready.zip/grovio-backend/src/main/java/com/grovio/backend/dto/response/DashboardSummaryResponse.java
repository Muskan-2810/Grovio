package com.grovio.backend.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Single aggregated payload for the dashboard screen — mirrors the
 * BFF-style GET /api/dashboard endpoint from the API design phase.
 * Reduces the frontend to one request instead of six.
 */
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DashboardSummaryResponse {
    private String mentorInsight;              // hero headline, derived from progress + top mission task
    private ProgressResponse progress;          // career pulse ring + streak
    private List<MissionTaskResponse> todayMission;
    private List<OpportunityMatchResponse> matchedOpportunities; // type = INTERNSHIP/JOB
    private List<OpportunityMatchResponse> matchedHackathons;    // type = HACKATHON
    private List<LearningTopicResponse> weeklyPlan;
    private List<WatchlistItemResponse> watchlist;
    private List<TrendingCompanyResponse> trendingCompanies;
}
