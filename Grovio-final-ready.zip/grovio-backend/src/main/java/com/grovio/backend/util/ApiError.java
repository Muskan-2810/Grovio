package com.grovio.backend.util;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.Instant;
import java.util.List;

/**
 * Standard error envelope returned by the GlobalExceptionHandler.
 * Mirrors the shape agreed on in the API design phase.
 */
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ApiError {

    @Builder.Default
    private boolean success = false;

    @Builder.Default
    private Instant timestamp = Instant.now();

    private String path;
    private String errorCode;
    private String message;
    private List<String> details;
}
