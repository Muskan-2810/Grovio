package com.grovio.backend.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * A single internship / job / hackathon listing. Shared foundation for the
 * Dashboard's "Matched for you" + "Hackathons worth your time" cards, and
 * for the future Opportunity Hub module.
 */
@Entity
@Table(name = "opportunities")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Opportunity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String companyName;

    @Column(name = "company_initials")
    private String companyInitials; // e.g. "RZ" for the avatar chip

    @Column(nullable = false)
    private String title;

    @Column(nullable = false)
    private String type; // INTERNSHIP, JOB, HACKATHON

    private String location;

    @Column(name = "compensation_or_prize")
    private String compensationOrPrize; // e.g. "₹50,000/mo" or "₹2L prize pool"

    @Column(nullable = false)
    private LocalDate deadline;

    @Column(name = "apply_url")
    private String applyUrl;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
    }
}
