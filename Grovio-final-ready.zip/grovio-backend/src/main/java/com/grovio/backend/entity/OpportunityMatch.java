package com.grovio.backend.entity;

import jakarta.persistence.*;
import lombok.*;

/**
 * Join between a User and an Opportunity, carrying the personalized match
 * score + one-line reasoning shown on the dashboard. Deterministic scoring
 * lives in the service layer (skill overlap) — the reasoning text is the
 * only part that may eventually be AI-generated (see AI System Architecture,
 * section 6: "AI Recommends Opportunities").
 */
@Entity
@Table(name = "opportunity_matches")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OpportunityMatch {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "opportunity_id", nullable = false)
    private Opportunity opportunity;

    @Column(name = "match_percent", nullable = false)
    private Integer matchPercent;

    @Column(length = 500)
    private String matchReason;

    @Column(name = "display_order")
    private Integer displayOrder;
}
