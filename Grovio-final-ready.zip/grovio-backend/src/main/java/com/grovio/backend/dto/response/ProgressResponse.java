package com.grovio.backend.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ProgressResponse {
    private Integer overallScore;
    private Integer resumeScore;
    private Integer dsaScore;
    private Integer projectsScore;
    private Integer aptitudeScore;
    private Integer communicationScore;
    private Integer weeklyDelta;
    private Integer streakCount;
    private Integer longestStreak;
    private LocalDate lastActiveDate;
}
