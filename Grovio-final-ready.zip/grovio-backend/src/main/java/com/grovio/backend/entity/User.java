package com.grovio.backend.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Table(name = "users", uniqueConstraints = @UniqueConstraint(columnNames = "email"))
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "full_name", nullable = false)
    private String fullName;

    @Column(nullable = false, unique = true)
    private String email;

    // Never serialized back to the client.
    @JsonIgnore
    @Column(nullable = false)
    private String password;

    private String college;

    private String branch;

    @Column(name = "graduation_year")
    private Integer graduationYear;

    // Collected during onboarding (Step 2). Free-form for now rather than an
    // enum, since the frontend's goal options aren't a fixed domain concept
    // yet — revisit as an enum if/when matching logic depends on it.
    @Column(name = "career_goal")
    private String careerGoal;

    // Collected during onboarding (Step 3). Stored as a single comma-joined
    // column instead of a separate user_strengths table — this is a small,
    // rarely-queried, read-mostly field, so a join table would be more
    // structure than the data currently needs. Revisit if strengths ever
    // need to be queried/filtered on their own (e.g. "find users strong in
    // SQL") rather than just displayed back to the same user.
    @Column(name = "strengths")
    private String strengths;

    @Column(name = "profile_picture")
    private String profilePicture;

    // Simple role model for now — everyone is a STUDENT unless changed later.
    // Kept as a plain string column rather than a separate table since Grovio
    // currently has a single role; this can be normalized later if an ADMIN
    // role / role table is introduced.
    @Column(nullable = false)
    @Builder.Default
    private String role = "STUDENT";

    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        this.updatedAt = LocalDateTime.now();
    }
}
