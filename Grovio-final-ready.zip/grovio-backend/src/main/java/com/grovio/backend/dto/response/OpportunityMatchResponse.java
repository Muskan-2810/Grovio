package com.grovio.backend.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class OpportunityMatchResponse {
    private Long id;
    private String companyName;
    private String companyInitials;
    private String title;
    private String type; // INTERNSHIP, JOB, HACKATHON
    private String location;
    private String compensationOrPrize;
    private Long daysLeft;
    private Integer matchPercent;
    private String matchReason;
    private String applyUrl;
}
