package com.grovio.backend.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ActivityLogResponse {
    private Long id;
    private String activityType;
    private String description;
    private LocalDateTime createdAt;
}
