package com.grovio.backend.repository;

import com.grovio.backend.entity.MissionTask;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

public interface MissionTaskRepository extends JpaRepository<MissionTask, Long> {
    List<MissionTask> findByUserIdAndMissionDateOrderByDisplayOrderAsc(Long userId, LocalDate missionDate);
}
