package com.grovio.backend.controller;

import com.grovio.backend.dto.request.UpdateProfileRequest;
import com.grovio.backend.dto.response.UserResponse;
import com.grovio.backend.service.AuthService;
import com.grovio.backend.util.ApiResponse;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Dashboard/onboarding-facing profile endpoints. GET reuses
 * AuthService.getCurrentUser() (Module 1, untouched). PATCH is new in
 * Phase 1 — it's what lets onboarding's career goal + strengths selection
 * actually persist instead of being thrown away on navigate('/dashboard').
 */
@RestController
@RequestMapping("/api/profile")
@RequiredArgsConstructor
public class ProfileController {

    private final AuthService authService;

    @GetMapping("/me")
    public ApiResponse<UserResponse> getMyProfile(Authentication authentication) {
        return ApiResponse.of(authService.getCurrentUser(authentication.getName()));
    }

    @PatchMapping("/me")
    public ApiResponse<UserResponse> updateMyProfile(
            Authentication authentication,
            @Valid @RequestBody UpdateProfileRequest request
    ) {
        return ApiResponse.of(authService.updateProfile(authentication.getName(), request));
    }
}
