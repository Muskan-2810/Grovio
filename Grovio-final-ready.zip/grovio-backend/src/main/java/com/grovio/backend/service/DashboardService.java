package com.grovio.backend.service;

import com.grovio.backend.dto.response.*;

import java.util.List;

public interface DashboardService {

    DashboardSummaryResponse getSummary(String email);

    ProgressResponse getProgress(String email);

    List<ActivityLogResponse> getRecentActivity(String email, int limit);

    List<OpportunityMatchResponse> getRecommendedOpportunities(String email);

    List<LearningTopicResponse> getContinueLearning(String email);
}
