package com.grovio.backend.dto.request;

import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * Body for PATCH /api/profile/me. Both fields are optional — a request can
 * update just the goal, just strengths, or both (partial update).
 */
@Getter
@Setter
public class UpdateProfileRequest {

    @Size(max = 100, message = "Career goal looks too long")
    private String careerGoal;

    @Size(max = 20, message = "That's a lot of strengths — pick your top ones")
    private List<@Size(max = 50, message = "One of the strengths looks too long") String> strengths;
}
