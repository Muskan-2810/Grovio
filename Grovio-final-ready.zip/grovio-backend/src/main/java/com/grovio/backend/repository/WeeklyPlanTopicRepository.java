package com.grovio.backend.repository;

import com.grovio.backend.entity.WeeklyPlanTopic;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

public interface WeeklyPlanTopicRepository extends JpaRepository<WeeklyPlanTopic, Long> {
    List<WeeklyPlanTopic> findByUserIdAndWeekStartDateOrderByDisplayOrderAsc(Long userId, LocalDate weekStartDate);
}
