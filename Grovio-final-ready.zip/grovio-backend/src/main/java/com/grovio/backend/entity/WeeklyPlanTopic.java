package com.grovio.backend.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

/**
 * Backs the "This week's plan" / Continue Learning progress bars
 * (e.g. "Recursion & Backtracking — 82%").
 */
@Entity
@Table(name = "weekly_plan_topics")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class WeeklyPlanTopic {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Column(nullable = false)
    private String topic;

    @Builder.Default
    @Column(name = "progress_percent")
    private Integer progressPercent = 0;

    @Column(length = 500)
    private String insight;

    @Column(name = "week_start_date", nullable = false)
    private LocalDate weekStartDate;

    @Column(name = "display_order")
    private Integer displayOrder;
}
