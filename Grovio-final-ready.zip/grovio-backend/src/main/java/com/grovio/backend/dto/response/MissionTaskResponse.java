package com.grovio.backend.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class MissionTaskResponse {
    private Long id;
    private String title;
    private String category;
    private Integer durationMinutes;
    private String priorityLabel;
    private String insight;
    private Boolean completed;
}
