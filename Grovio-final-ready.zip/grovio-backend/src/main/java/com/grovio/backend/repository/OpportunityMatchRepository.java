package com.grovio.backend.repository;

import com.grovio.backend.entity.OpportunityMatch;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface OpportunityMatchRepository extends JpaRepository<OpportunityMatch, Long> {

    List<OpportunityMatch> findByUserIdAndOpportunity_TypeOrderByDisplayOrderAsc(Long userId, String type);

    List<OpportunityMatch> findByUserIdOrderByDisplayOrderAsc(Long userId);
}
