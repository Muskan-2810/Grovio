package com.grovio.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GrovioBackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(GrovioBackendApplication.class, args);
    }
}
