package com.grovio.backend.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class WatchlistItemResponse {
    private Long id;
    private String title;
    private String insight;
    private Integer dueInDays;
    private String urgencyLevel;
}
