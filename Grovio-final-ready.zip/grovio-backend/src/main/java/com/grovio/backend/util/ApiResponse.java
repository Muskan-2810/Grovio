package com.grovio.backend.util;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.Instant;

/**
 * Standard success envelope for every API response in Grovio.
 * Keeps the frontend contract consistent across all modules.
 */
@Getter
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ApiResponse<T> {

    private boolean success;
    private Instant timestamp;
    private T data;

    public static <T> ApiResponse<T> of(T data) {
        return new ApiResponse<>(true, Instant.now(), data);
    }
}
