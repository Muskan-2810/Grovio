package com.grovio.backend.controller;

import com.grovio.backend.dto.response.*;
import com.grovio.backend.service.DashboardService;
import com.grovio.backend.util.ApiResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/dashboard")
@RequiredArgsConstructor
public class DashboardController {

    private final DashboardService dashboardService;

    // GET /api/dashboard — single aggregated payload for the whole screen
    @GetMapping
    public ApiResponse<DashboardSummaryResponse> getSummary(Authentication authentication) {
        return ApiResponse.of(dashboardService.getSummary(authentication.getName()));
    }

    // GET /api/dashboard/progress — Career Pulse ring + streak
    @GetMapping("/progress")
    public ApiResponse<ProgressResponse> getProgress(Authentication authentication) {
        return ApiResponse.of(dashboardService.getProgress(authentication.getName()));
    }

    // GET /api/dashboard/activity?limit=10 — Recent Activity
    @GetMapping("/activity")
    public ApiResponse<List<ActivityLogResponse>> getRecentActivity(
            Authentication authentication,
            @RequestParam(defaultValue = "10") int limit
    ) {
        return ApiResponse.of(dashboardService.getRecentActivity(authentication.getName(), limit));
    }

    // GET /api/dashboard/opportunities — Recommended Opportunities (+ hackathons)
    @GetMapping("/opportunities")
    public ApiResponse<List<OpportunityMatchResponse>> getRecommendedOpportunities(Authentication authentication) {
        return ApiResponse.of(dashboardService.getRecommendedOpportunities(authentication.getName()));
    }

    // GET /api/dashboard/learning — Continue Learning / this week's plan
    @GetMapping("/learning")
    public ApiResponse<List<LearningTopicResponse>> getContinueLearning(Authentication authentication) {
        return ApiResponse.of(dashboardService.getContinueLearning(authentication.getName()));
    }
}
