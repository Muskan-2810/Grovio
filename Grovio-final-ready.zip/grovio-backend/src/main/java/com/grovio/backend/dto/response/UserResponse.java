package com.grovio.backend.dto.response;

import com.grovio.backend.entity.User;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.Arrays;
import java.util.List;

@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UserResponse {

    private Long id;
    private String fullName;
    private String email;
    private String college;
    private String branch;
    private Integer graduationYear;
    private String careerGoal;
    private List<String> strengths;
    private String profilePicture;

    public static UserResponse fromEntity(User user) {
        return UserResponse.builder()
                .id(user.getId())
                .fullName(user.getFullName())
                .email(user.getEmail())
                .college(user.getCollege())
                .branch(user.getBranch())
                .graduationYear(user.getGraduationYear())
                .careerGoal(user.getCareerGoal())
                .strengths(splitStrengths(user.getStrengths()))
                .profilePicture(user.getProfilePicture())
                .build();
    }

    // Storage is a single comma-joined column (see User.strengths) — this is
    // the one place that format is translated back into a real list for API
    // consumers, so nothing outside this DTO needs to know about the join.
    private static List<String> splitStrengths(String stored) {
        if (stored == null || stored.isBlank()) {
            return List.of();
        }
        return Arrays.stream(stored.split(","))
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .toList();
    }
}
