package com.grovio.backend.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class LearningTopicResponse {
    private Long id;
    private String topic;
    private Integer progressPercent;
    private String insight;
}
