package com.grovio.backend.service.impl;

import com.grovio.backend.dto.response.*;
import com.grovio.backend.entity.*;
import com.grovio.backend.exception.ResourceNotFoundException;
import com.grovio.backend.repository.*;
import com.grovio.backend.service.DashboardService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAdjusters;
import java.util.List;

@Service
@RequiredArgsConstructor
public class DashboardServiceImpl implements DashboardService {

    private final UserRepository userRepository;
    private final UserProgressRepository userProgressRepository;
    private final MissionTaskRepository missionTaskRepository;
    private final WeeklyPlanTopicRepository weeklyPlanTopicRepository;
    private final WatchlistItemRepository watchlistItemRepository;
    private final OpportunityMatchRepository opportunityMatchRepository;
    private final TrendingCompanyRepository trendingCompanyRepository;
    private final ActivityLogRepository activityLogRepository;

    @Override
    @Transactional
    public DashboardSummaryResponse getSummary(String email) {
        User user = resolveUser(email);

        ProgressResponse progress = toProgressResponse(resolveOrCreateProgress(user));
        List<MissionTaskResponse> mission = missionTaskRepository
                .findByUserIdAndMissionDateOrderByDisplayOrderAsc(user.getId(), LocalDate.now())
                .stream().map(this::toMissionResponse).toList();

        List<OpportunityMatchResponse> allMatches = opportunityMatchRepository
                .findByUserIdOrderByDisplayOrderAsc(user.getId())
                .stream().map(this::toOpportunityMatchResponse).toList();

        List<OpportunityMatchResponse> matchedOpportunities = allMatches.stream()
                .filter(m -> "INTERNSHIP".equals(m.getType()) || "JOB".equals(m.getType()))
                .toList();
        List<OpportunityMatchResponse> matchedHackathons = allMatches.stream()
                .filter(m -> "HACKATHON".equals(m.getType()))
                .toList();

        List<LearningTopicResponse> weeklyPlan = weeklyPlanTopicRepository
                .findByUserIdAndWeekStartDateOrderByDisplayOrderAsc(user.getId(), currentWeekStart())
                .stream().map(this::toLearningTopicResponse).toList();

        List<WatchlistItemResponse> watchlist = watchlistItemRepository
                .findByUserIdOrderByDisplayOrderAsc(user.getId())
                .stream().map(this::toWatchlistResponse).toList();

        List<TrendingCompanyResponse> trending = trendingCompanyRepository
                .findAllByOrderByDisplayOrderAsc()
                .stream().map(c -> TrendingCompanyResponse.builder()
                        .name(c.getName()).trendLabel(c.getTrendLabel()).build())
                .toList();

        String mentorInsight = buildMentorInsight(user, progress, mission);

        return DashboardSummaryResponse.builder()
                .mentorInsight(mentorInsight)
                .progress(progress)
                .todayMission(mission)
                .matchedOpportunities(matchedOpportunities)
                .matchedHackathons(matchedHackathons)
                .weeklyPlan(weeklyPlan)
                .watchlist(watchlist)
                .trendingCompanies(trending)
                .build();
    }

    @Override
    @Transactional
    public ProgressResponse getProgress(String email) {
        User user = resolveUser(email);
        return toProgressResponse(resolveOrCreateProgress(user));
    }

    @Override
    public List<ActivityLogResponse> getRecentActivity(String email, int limit) {
        User user = resolveUser(email);
        return activityLogRepository
                .findByUserIdOrderByCreatedAtDesc(user.getId(), PageRequest.of(0, Math.min(50, Math.max(1, limit))))
                .stream()
                .map(a -> ActivityLogResponse.builder()
                        .id(a.getId())
                        .activityType(a.getActivityType())
                        .description(a.getDescription())
                        .createdAt(a.getCreatedAt())
                        .build())
                .toList();
    }

    @Override
    public List<OpportunityMatchResponse> getRecommendedOpportunities(String email) {
        User user = resolveUser(email);
        return opportunityMatchRepository.findByUserIdOrderByDisplayOrderAsc(user.getId())
                .stream().map(this::toOpportunityMatchResponse).toList();
    }

    @Override
    public List<LearningTopicResponse> getContinueLearning(String email) {
        User user = resolveUser(email);
        return weeklyPlanTopicRepository
                .findByUserIdAndWeekStartDateOrderByDisplayOrderAsc(user.getId(), currentWeekStart())
                .stream().map(this::toLearningTopicResponse).toList();
    }

    // ---------------------------------------------------------------
    // Helpers
    // ---------------------------------------------------------------

    private User resolveUser(String email) {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
    }

    /**
     * Every new user gets a zeroed-out progress row lazily, the first time
     * the dashboard is loaded, rather than requiring Auth's register() to
     * know about this module (keeps Module 1 untouched, as instructed).
     */
    private UserProgress resolveOrCreateProgress(User user) {
        return userProgressRepository.findByUserId(user.getId())
                .orElseGet(() -> userProgressRepository.save(
                        UserProgress.builder().user(user).build()
                ));
    }

    private LocalDate currentWeekStart() {
        return LocalDate.now().with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY));
    }

    private String buildMentorInsight(User user, ProgressResponse progress, List<MissionTaskResponse> mission) {
        String firstName = user.getFullName() == null ? "there"
                : user.getFullName().split(" ")[0];

        if (!mission.isEmpty()) {
            MissionTaskResponse top = mission.get(0);
            return "Morning, " + firstName + ". " + top.getInsight();
        }

        if (progress.getWeeklyDelta() != null && progress.getWeeklyDelta() > 0) {
            return "Morning, " + firstName + ". Your readiness score is up "
                    + progress.getWeeklyDelta() + " points this week — keep the streak going.";
        }

        return "Morning, " + firstName + ". Let's plan today's focus.";
    }

    private ProgressResponse toProgressResponse(UserProgress p) {
        return ProgressResponse.builder()
                .overallScore(p.getOverallScore())
                .resumeScore(p.getResumeScore())
                .dsaScore(p.getDsaScore())
                .projectsScore(p.getProjectsScore())
                .aptitudeScore(p.getAptitudeScore())
                .communicationScore(p.getCommunicationScore())
                .weeklyDelta(p.getWeeklyDelta())
                .streakCount(p.getStreakCount())
                .longestStreak(p.getLongestStreak())
                .lastActiveDate(p.getLastActiveDate())
                .build();
    }

    private MissionTaskResponse toMissionResponse(MissionTask t) {
        return MissionTaskResponse.builder()
                .id(t.getId())
                .title(t.getTitle())
                .category(t.getCategory())
                .durationMinutes(t.getDurationMinutes())
                .priorityLabel(t.getPriorityLabel())
                .insight(t.getInsight())
                .completed(t.getCompleted())
                .build();
    }

    private LearningTopicResponse toLearningTopicResponse(WeeklyPlanTopic t) {
        return LearningTopicResponse.builder()
                .id(t.getId())
                .topic(t.getTopic())
                .progressPercent(t.getProgressPercent())
                .insight(t.getInsight())
                .build();
    }

    private WatchlistItemResponse toWatchlistResponse(WatchlistItem w) {
        return WatchlistItemResponse.builder()
                .id(w.getId())
                .title(w.getTitle())
                .insight(w.getInsight())
                .dueInDays(w.getDueInDays())
                .urgencyLevel(w.getUrgencyLevel())
                .build();
    }

    private OpportunityMatchResponse toOpportunityMatchResponse(OpportunityMatch m) {
        Opportunity o = m.getOpportunity();
        long daysLeft = ChronoUnit.DAYS.between(LocalDate.now(), o.getDeadline());

        return OpportunityMatchResponse.builder()
                .id(o.getId())
                .companyName(o.getCompanyName())
                .companyInitials(o.getCompanyInitials())
                .title(o.getTitle())
                .type(o.getType())
                .location(o.getLocation())
                .compensationOrPrize(o.getCompensationOrPrize())
                .daysLeft(Math.max(0, daysLeft))
                .matchPercent(m.getMatchPercent())
                .matchReason(m.getMatchReason())
                .applyUrl(o.getApplyUrl())
                .build();
    }
}
