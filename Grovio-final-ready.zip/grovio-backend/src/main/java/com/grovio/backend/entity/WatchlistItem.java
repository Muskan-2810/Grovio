package com.grovio.backend.entity;

import jakarta.persistence.*;
import lombok.*;

/**
 * Backs the "Mentor's watchlist" card — deadline-ish reminders ordered by urgency.
 */
@Entity
@Table(name = "watchlist_items")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class WatchlistItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Column(nullable = false)
    private String title;

    @Column(length = 500)
    private String insight;

    @Column(name = "due_in_days")
    private Integer dueInDays;

    @Column(name = "urgency_level", nullable = false)
    private String urgencyLevel; // HIGH, MEDIUM, LOW — drives pill color on the frontend

    @Column(name = "display_order")
    private Integer displayOrder;
}
