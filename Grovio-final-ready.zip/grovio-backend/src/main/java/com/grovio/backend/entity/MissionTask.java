package com.grovio.backend.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

/**
 * A single item in "Today's mission" — the prioritized task list on the
 * dashboard. priorityLabel/insight are pre-generated text (by the AI
 * Study Planner / Mentor pipeline) and stored here for fast, cheap reads —
 * the dashboard never calls the LLM directly.
 */
@Entity
@Table(name = "mission_tasks")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MissionTask {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Column(nullable = false)
    private String title;

    @Column(nullable = false)
    private String category; // DSA, RESUME, OPPORTUNITY, APTITUDE, etc.

    @Column(name = "duration_minutes")
    private Integer durationMinutes;

    @Column(name = "priority_label")
    private String priorityLabel; // "Priority 1", "Deadline", "Quick win"

    @Column(length = 500)
    private String insight; // short AI-authored reasoning line

    @Builder.Default
    private Boolean completed = false;

    @Column(name = "mission_date", nullable = false)
    private LocalDate missionDate;

    @Column(name = "display_order")
    private Integer displayOrder;
}
