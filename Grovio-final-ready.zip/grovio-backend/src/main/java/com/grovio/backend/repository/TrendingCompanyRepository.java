package com.grovio.backend.repository;

import com.grovio.backend.entity.TrendingCompany;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TrendingCompanyRepository extends JpaRepository<TrendingCompany, Long> {
    List<TrendingCompany> findAllByOrderByDisplayOrderAsc();
}
