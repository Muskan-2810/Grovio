package com.grovio.backend.service;

import com.grovio.backend.dto.request.LoginRequest;
import com.grovio.backend.dto.request.RegisterRequest;
import com.grovio.backend.dto.request.UpdateProfileRequest;
import com.grovio.backend.dto.response.AuthResponse;
import com.grovio.backend.dto.response.UserResponse;

public interface AuthService {

    AuthResponse register(RegisterRequest request);

    AuthResponse login(LoginRequest request);

    UserResponse getCurrentUser(String email);

    // Lives here rather than in a separate ProfileService: this is currently
    // the only place that owns "look up the current user", and one more
    // method didn't justify a second service + interface pair for it.
    UserResponse updateProfile(String email, UpdateProfileRequest request);
}
