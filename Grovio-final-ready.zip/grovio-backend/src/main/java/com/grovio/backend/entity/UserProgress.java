package com.grovio.backend.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * One row per user. Backs the "Career Pulse" ring and streak chip.
 * Component scores are 0-100; overallScore is the weighted composite
 * (see AI System Architecture doc — computed deterministically, not by AI).
 */
@Entity
@Table(name = "user_progress")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserProgress {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false, unique = true)
    private User user;

    @Builder.Default
    @Column(name = "overall_score")
    private Integer overallScore = 0;

    @Builder.Default
    @Column(name = "resume_score")
    private Integer resumeScore = 0;

    @Builder.Default
    @Column(name = "dsa_score")
    private Integer dsaScore = 0;

    @Builder.Default
    @Column(name = "projects_score")
    private Integer projectsScore = 0;

    @Builder.Default
    @Column(name = "aptitude_score")
    private Integer aptitudeScore = 0;

    @Builder.Default
    @Column(name = "communication_score")
    private Integer communicationScore = 0;

    @Builder.Default
    @Column(name = "weekly_delta")
    private Integer weeklyDelta = 0; // change vs 7 days ago, can be negative

    @Builder.Default
    @Column(name = "streak_count")
    private Integer streakCount = 0;

    @Builder.Default
    @Column(name = "longest_streak")
    private Integer longestStreak = 0;

    @Column(name = "last_active_date")
    private LocalDate lastActiveDate;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @PrePersist
    @PreUpdate
    protected void touch() {
        this.updatedAt = LocalDateTime.now();
    }
}
