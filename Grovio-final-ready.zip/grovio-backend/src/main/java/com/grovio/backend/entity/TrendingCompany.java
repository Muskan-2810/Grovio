package com.grovio.backend.entity;

import jakarta.persistence.*;
import lombok.*;

/**
 * Global (not per-user) reference data for the "Trending in your target
 * track" strip. Curated/updated by an ingestion job or admin tooling later.
 */
@Entity
@Table(name = "trending_companies")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TrendingCompany {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @Column(name = "trend_label", nullable = false)
    private String trendLabel; // e.g. "+18% postings ↑", "Closing soon"

    @Column(name = "display_order")
    private Integer displayOrder;
}
