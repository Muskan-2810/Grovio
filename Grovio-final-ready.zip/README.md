# Grovio — AI Career Companion

Grovio is a full-stack career companion for students. It combines a Spring Boot + PostgreSQL backend with a React/Vite frontend to provide authenticated profiles, career progress, missions, opportunity matches, learning plans and an extensible foundation for future AI features.

## Current implementation

- JWT authentication with BCrypt password hashing
- Protected React routes with persisted sessions
- PostgreSQL persistence through Spring Data JPA
- Dashboard aggregation API
- Career progress and streak data
- Opportunity matching records with match percentage/reason
- Opportunity Hub with client-side search/type filtering
- Profile editing through `PATCH /api/profile/me`
- Onboarding wizard wired to registration + profile persistence
- Explicit NOT_IMPLEMENTED handling for resume analysis until a real backend pipeline exists

## Architecture

```text
React/Vite frontend
       |
       | HTTP + Bearer JWT
       v
Spring Boot REST API
       |
       v
Spring Security + JWT
       |
       v
Spring Data JPA
       |
       v
PostgreSQL
```

## Local setup

### Backend

Set these environment variables before starting Spring Boot:

```text
DATABASE_URL=jdbc:postgresql://localhost:5432/grovio
DATABASE_USERNAME=postgres
DATABASE_PASSWORD=<your-password>
JWT_SECRET=<base64-encoded-secret>
JWT_EXPIRATION_MS=3600000
CORS_ALLOWED_ORIGINS=http://localhost:5173,http://localhost:3000
PORT=8080
```

Then:

```powershell
cd grovio-backend
a mvn spring-boot:run
```

Replace `a mvn` with `mvn` if copying manually; the intended command is:

```powershell
mvn spring-boot:run
```

Health check:

```text
GET http://localhost:8080/api/health
```

### Frontend

```powershell
cd grovio-frontend
npm install
npm run dev
```

The frontend expects:

```text
VITE_API_BASE_URL=http://localhost:8080/api
```

in `.env`.

## Important limitations

- Resume upload/analysis is intentionally not faked; the UI reports that the backend endpoint is not implemented yet.
- Opportunity search/filtering is currently client-side over matched records.
- Seed opportunity/activity data is illustrative development data.
- `ddl-auto=update` is still used during development. A production release should move schema changes to Flyway/Liquibase and use `validate`.

## Next engineering milestones

1. Real resume upload + parsing pipeline.
2. Skill-aware deterministic opportunity scoring with evaluation metrics.
3. Persistent opportunity bookmarks/application tracking.
4. Backend/frontend automated tests and CI.
5. Production migration tooling, rate limiting and security hardening.
6. AI mentor and AI-assisted recommendation features backed by measurable evaluation.
